package com.secureshare.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.TypedValue;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 5001;
    private EditText server,email,smtp,imap,user,pass,secret,poll;
    private TextView status,folder;
    private AppConfig cfg;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        cfg=AppConfig.load(this);
        build();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);
    }

    private int dp(int v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,v,getResources().getDisplayMetrics());}
    private int color(String hex){return Color.parseColor(hex);}

    private GradientDrawable round(int bg,String strokeHex){
        GradientDrawable g=new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(16));
        if(strokeHex!=null)g.setStroke(dp(1),color(strokeHex));
        return g;
    }

    private TextView sectionTitle(String text){
        TextView t=new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(color("#0F172A"));
        t.setPadding(0,0,0,dp(10));
        return t;
    }

    private LinearLayout card(){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(16),dp(16),dp(16));
        box.setBackground(round(color("#FFFFFF"),"#E2E8F0"));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.bottomMargin=dp(14);
        box.setLayoutParams(lp);
        return box;
    }

    private EditText input(LinearLayout root,String label,String value,boolean password){
        TextView l=new TextView(this);
        l.setText(label);
        l.setTextColor(color("#475569"));
        l.setTextSize(13);
        l.setPadding(0,dp(10),0,dp(4));
        root.addView(l);
        EditText e=new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextSize(18);
        e.setPadding(dp(12),dp(12),dp(12),dp(12));
        e.setBackground(round(color("#F8FAFC"),"#CBD5E1"));
        if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(e,new LinearLayout.LayoutParams(-1,-2));
        return e;
    }

    private Button button(String text, boolean primary){
        Button b=new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(16);
        b.setTextColor(primary?Color.WHITE:color("#0F172A"));
        b.setPadding(dp(12),dp(12),dp(12),dp(12));
        b.setBackground(round(primary?color("#2563EB"):color("#EFF6FF"), primary?null:"#BFDBFE"));
        return b;
    }

    private LinearLayout actionRow(View... views){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(views.length);
        for(int i=0;i<views.length;i++){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
            if(i!=0)lp.setMarginStart(dp(8));
            row.addView(views[i],lp);
        }
        return row;
    }

    private TextView infoText(String text, int fg, int bg){
        TextView t=new TextView(this);
        t.setText(text);
        t.setTextColor(fg);
        t.setTextSize(14);
        t.setPadding(dp(12),dp(10),dp(12),dp(10));
        GradientDrawable g=new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(14));
        t.setBackground(g);
        return t;
    }

    private void build(){
        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(color("#F1F5F9"));
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(18),dp(16),dp(24));
        sv.addView(root,new ScrollView.LayoutParams(-1,-2));

        LinearLayout hero=card();
        TextView title=new TextView(this);
        title.setText("SecureShare");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(color("#0F172A"));
        hero.addView(title);
        TextView subtitle=new TextView(this);
        subtitle.setText("همگام‌سازی امن فایل بین دستگاه‌ها از طریق Mail Server مجاز");
        subtitle.setTextColor(color("#475569"));
        subtitle.setPadding(0,dp(6),0,dp(14));
        hero.addView(subtitle);
        status=infoText("آماده", color("#0F172A"), color("#E0F2FE"));
        hero.addView(status);
        folder=infoText("پوشه گوشی: در حال آماده‌سازی...", color("#334155"), color("#F8FAFC"));
        LinearLayout.LayoutParams flp=(LinearLayout.LayoutParams)folder.getLayoutParams();
        folder.setPadding(dp(12),dp(12),dp(12),dp(12));
        flp = new LinearLayout.LayoutParams(-1,-2);
        flp.topMargin=dp(10);
        hero.addView(folder,flp);

        Button syncB=button("همگام‌سازی الآن", true);
        Button importB=button("افزودن فایل", false);
        Button testB=button("تست اتصال", false);
        LinearLayout row1=actionRow(syncB,importB,testB);
        LinearLayout.LayoutParams rowLp=new LinearLayout.LayoutParams(-1,-2); rowLp.topMargin=dp(14);
        hero.addView(row1,rowLp);
        Button openFolderB=button("باز کردن پوشه SecureShare", false);
        LinearLayout.LayoutParams oflp=new LinearLayout.LayoutParams(-1,-2); oflp.topMargin=dp(10);
        hero.addView(openFolderB,oflp);
        root.addView(hero);

        LinearLayout form=card();
        form.addView(sectionTitle("تنظیمات اتصال"));
        server=input(form,"Mail Server",cfg.server,false);
        email=input(form,"ایمیل",cfg.email,false);
        smtp=input(form,"SMTP Port",String.valueOf(cfg.smtpPort),false);
        imap=input(form,"IMAP Port",String.valueOf(cfg.imapPort),false);
        user=input(form,"نام کاربری",cfg.username,false);
        pass=input(form,"رمز ایمیل",cfg.password,true);
        secret=input(form,"رمز مشترک رمزگذاری",cfg.sharedSecret,true);
        poll=input(form,"فاصله Sync (ثانیه)",String.valueOf(cfg.pollSeconds),false);
        Button saveB=button("ذخیره و فعال‌کردن Sync پس‌زمینه", true);
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2); slp.topMargin=dp(14);
        form.addView(saveB,slp);
        TextView note=new TextView(this);
        note.setText("اگر قبلاً با رمز مشترک دیگری فایل فرستاده باشی، پیام‌های قدیمی ممکن است خوانده نشوند ولی از این نسخه به بعد Sync متوقف نخواهد شد.");
        note.setTextColor(color("#64748B"));
        note.setTextSize(13);
        note.setPadding(0,dp(12),0,0);
        form.addView(note);
        root.addView(form);

        setContentView(sv);
        try{folder.setText("پوشه گوشی: "+new SyncEngine(this,cfg).folder().getAbsolutePath());}catch(Exception e){folder.setText("خطای پوشه: "+e.getMessage());}

        saveB.setOnClickListener(v->saveAndStart());
        syncB.setOnClickListener(v->syncNow());
        testB.setOnClickListener(v->testConn());
        importB.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);});
        openFolderB.setOnClickListener(v->openSecureShareFolder());
    }

    private AppConfig readForm(){AppConfig c=cfg;c.server=server.getText().toString().trim();c.email=email.getText().toString().trim();c.smtpPort=parseInt(smtp.getText().toString(),465);c.imapPort=parseInt(imap.getText().toString(),993);c.username=user.getText().toString().trim();c.password=pass.getText().toString();c.sharedSecret=secret.getText().toString().trim();c.pollSeconds=Math.max(30,parseInt(poll.getText().toString(),60));return c;}
    private int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    private void setStatus(String txt, boolean error){
        status.setText(txt);
        GradientDrawable g=new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(error?color("#FEE2E2"):color("#DBEAFE"));
        status.setTextColor(error?color("#991B1B"):color("#1E3A8A"));
        status.setBackground(g);
    }
    private void saveAndStart(){try{cfg=readForm();cfg.save(this);Intent i=new Intent(this,SyncService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);setStatus("تنظیمات ذخیره شد و Sync پس‌زمینه فعال شد",false);}catch(Exception e){setStatus("خطا: "+e.getMessage(),true);}}
    private void syncNow(){setStatus("در حال Sync...",false);new Thread(()->{try{AppConfig c=readForm();SyncEngine eng=new SyncEngine(this,c);eng.sync();String msg="همگام‌سازی انجام شد — "+eng.getLastResult().summary();runOnUiThread(()->setStatus(msg,false));}catch(Exception e){runOnUiThread(()->setStatus("خطا: "+e.getMessage(),true));}}).start();}
    private void testConn(){setStatus("در حال تست SMTP/IMAP...",false);new Thread(()->{try{MailTransport.test(readForm());runOnUiThread(()->setStatus("SMTP و IMAP موفق بود",false));}catch(Exception e){runOnUiThread(()->setStatus("خطا: "+e.getMessage(),true));}}).start();}
    private String displayName(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}return "file.bin";}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_FILE&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();new Thread(()->{try{SyncEngine e=new SyncEngine(this,readForm());File dst=new File(e.folder(),displayName(u));try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);}e.sync();String msg="فایل اضافه شد: "+dst.getName()+" — "+e.getLastResult().summary();runOnUiThread(()->setStatus(msg,false));}catch(Exception ex){runOnUiThread(()->setStatus("خطا: "+ex.getMessage(),true));}}).start();}}

    private void openSecureShareFolder(){try{SyncEngine e=new SyncEngine(this,readForm());showFolder(e.folder(),e.folder());}catch(Exception ex){setStatus("خطای بازکردن پوشه: "+ex.getMessage(),true);}}
    private void showFolder(File root,File dir){
        File[] raw=dir.listFiles(f->!f.getName().equals(".secureshare"));
        if(raw==null)raw=new File[0];
        Arrays.sort(raw,(a,b)->{if(a.isDirectory()!=b.isDirectory())return a.isDirectory()?-1:1;return a.getName().compareToIgnoreCase(b.getName());});
        final File[] files=raw;
        boolean hasParent=!sameFile(root,dir);
        String[] labels=new String[files.length+(hasParent?1:0)];
        int off=0;if(hasParent){labels[0]="⬆  پوشه بالا";off=1;}
        for(int i=0;i<files.length;i++){
            String extra = files[i].isDirectory()?"":("  ("+human(files[i].length())+")");
            labels[i+off]=(files[i].isDirectory()?"📁  ":"📄  ")+files[i].getName()+extra;
        }
        String rel=sameFile(root,dir)?"SecureShare":dir.getName();
        new AlertDialog.Builder(this).setTitle(rel).setItems(labels,(d,which)->{
            if(hasParent&&which==0){File p=dir.getParentFile();if(p!=null)showFolder(root,p);return;}
            File f=files[which-(hasParent?1:0)];
            if(f.isDirectory())showFolder(root,f);else showFileActions(root,dir,f);
        }).setNegativeButton("بستن",null).show();
    }
    private void showFileActions(File root, File currentDir, File f){
        String[] ops = {"باز کردن", "حذف فایل"};
        new AlertDialog.Builder(this)
                .setTitle(f.getName())
                .setItems(ops,(d,w)->{
                    if(w==0) openFile(root,f);
                    else confirmDelete(root,currentDir,f);
                })
                .setNegativeButton("انصراف",null)
                .show();
    }
    private void confirmDelete(File root, File currentDir, File f){
        new AlertDialog.Builder(this)
                .setTitle("حذف فایل")
                .setMessage("فایل «"+f.getName()+"» حذف شود؟ این حذف در Sync بعدی به دستگاه دیگر هم اعمال می‌شود.")
                .setPositiveButton("حذف",(d,w)->deleteAndSync(root,currentDir,f))
                .setNegativeButton("انصراف",null)
                .show();
    }
    private void deleteAndSync(File root, File currentDir, File f){
        new Thread(()->{
            try{
                if(!f.delete()) throw new IOException("حذف فایل انجام نشد");
                SyncEngine eng = new SyncEngine(this, readForm());
                eng.sync();
                runOnUiThread(()->{
                    setStatus("فایل حذف شد — "+eng.getLastResult().summary(), false);
                    showFolder(root,currentDir);
                });
            }catch(Exception ex){runOnUiThread(()->setStatus("خطا در حذف: "+ex.getMessage(),true));}
        }).start();
    }
    private boolean sameFile(File a,File b){try{return a.getCanonicalPath().equals(b.getCanonicalPath());}catch(Exception e){return a.equals(b);}}
    private void openFile(File root,File f){try{Uri uri=SecureShareFileProvider.uriFor(this,root,f);String ext=MimeTypeMap.getFileExtensionFromUrl(f.getName());String mime=ext==null?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.US));if(mime==null)mime="application/octet-stream";Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(ActivityNotFoundException e){Toast.makeText(this,"برنامه‌ای برای باز کردن این فایل پیدا نشد",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"خطا: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String human(long n){if(n<1024)return n+" B";double v=n/1024.0;String[] u={"KB","MB","GB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return new DecimalFormat("0.#").format(v)+" "+u[i];}
}
