package com.secureshare.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int PICK_FILE=5001, STORAGE_REQ=5002;
    private EditText server,email,user,pass;
    private TextView status,folder;
    private AppConfig cfg;
    private Typeface iranSans;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        try{iranSans=Typeface.createFromAsset(getAssets(),"IRANSansWeb-Medium.ttf");}catch(Exception ignored){iranSans=Typeface.DEFAULT;}
        cfg=AppConfig.load(this);build();ensureStoragePermission();
    }
    private int dp(int v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,v,getResources().getDisplayMetrics());}
    private int color(String h){return Color.parseColor(h);}
    private GradientDrawable bg(int c,String stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(radius));if(stroke!=null)g.setStroke(dp(1),color(stroke));return g;}
    private void font(View v){if(v instanceof TextView)((TextView)v).setTypeface(iranSans);if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)font(g.getChildAt(i));}}
    private LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(16),dp(16),dp(16));x.setBackground(bg(Color.WHITE,"#DDE5EE",18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(14);x.setLayoutParams(lp);return x;}
    private Button button(String t,boolean primary){Button b=new Button(this);b.setAllCaps(false);b.setText(t);b.setTextSize(15);b.setTextColor(primary?Color.WHITE:color("#174A72"));b.setBackground(bg(primary?color("#1769AA"):color("#EAF3FB"),primary?null:"#C9E0F2",12));b.setPadding(dp(10),dp(10),dp(10),dp(10));return b;}
    private EditText input(LinearLayout root,String label,String value,boolean password){TextView l=new TextView(this);l.setText(label);l.setTextColor(color("#52657A"));l.setTextSize(13);l.setPadding(0,dp(10),0,dp(5));root.addView(l);EditText e=new EditText(this);e.setText(value);e.setSingleLine(true);e.setTextSize(17);e.setPadding(dp(12),dp(11),dp(12),dp(11));e.setBackground(bg(color("#FAFCFE"),"#CCD8E4",11));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);root.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
    private TextView pill(String t,int fg,int bc){TextView v=new TextView(this);v.setText(t);v.setTextColor(fg);v.setTextSize(14);v.setPadding(dp(12),dp(10),dp(12),dp(10));v.setBackground(bg(bc,null,12));return v;}
    private LinearLayout row(View... vs){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);for(int i=0;i<vs.length;i++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);if(i>0)lp.setMarginStart(dp(7));r.addView(vs[i],lp);}return r;}

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setBackgroundColor(color("#EEF3F9"));LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(15),dp(18),dp(15),dp(24));sv.addView(root);
        LinearLayout hero=card();hero.setBackground(bg(color("#0F4C81"),null,18));TextView badge=new TextView(this);badge.setText("MANUAL SYNC • DOCUMENTS");badge.setTextColor(color("#D8EBFA"));badge.setTextSize(11);hero.addView(badge);TextView title=new TextView(this);title.setText("SecureShare");title.setTextColor(Color.WHITE);title.setTextSize(30);title.setTypeface(iranSans,Typeface.BOLD);title.setPadding(0,dp(5),0,0);hero.addView(title);TextView sub=new TextView(this);sub.setText("همگام‌سازی دستی با Documents وب‌میل");sub.setTextColor(color("#DBECF9"));sub.setPadding(0,dp(4),0,dp(12));hero.addView(sub);
        status=pill("آماده",color("#173A56"),color("#E8F3FB"));hero.addView(status);folder=pill("پوشه: Download/SecureShare",color("#334155"),color("#F8FAFC"));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(9);hero.addView(folder,fp);
        Button sync=button("همگام‌سازی الآن",true),add=button("افزودن فایل",false),test=button("تست Documents",false);LinearLayout ar=row(sync,add,test);LinearLayout.LayoutParams arp=new LinearLayout.LayoutParams(-1,-2);arp.topMargin=dp(12);hero.addView(ar,arp);Button browse=button("باز کردن فایل‌های SecureShare",false);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(8);hero.addView(browse,bp);root.addView(hero);

        LinearLayout form=card();TextView st=new TextView(this);st.setText("تنظیمات اتصال");st.setTextSize(19);st.setTextColor(color("#172033"));st.setTypeface(iranSans,Typeface.BOLD);form.addView(st);server=input(form,"Mail Server",cfg.server,false);email=input(form,"ایمیل",cfg.email,false);user=input(form,"نام کاربری",cfg.username,false);pass=input(form,"رمز ایمیل",cfg.password,true);Button save=button("ذخیره تنظیمات",true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(14);form.addView(save,sp);TextView note=new TextView(this);note.setText("همگام‌سازی خودکار غیرفعال است. رمز مشترک رمزگذاری داخل برنامه قرار دارد و چیزی برای وارد کردن ندارد.");note.setTextColor(color("#6A7888"));note.setTextSize(13);note.setPadding(0,dp(12),0,0);form.addView(note);root.addView(form);
        setContentView(sv);font(sv);
        try{folder.setText("پوشه: "+new SyncEngine(this,cfg).folder().getAbsolutePath());}catch(Exception e){folder.setText("پوشه: Download/SecureShare");}
        save.setOnClickListener(v->save());sync.setOnClickListener(v->syncNow());test.setOnClickListener(v->test());browse.setOnClickListener(v->openFolder());add.setOnClickListener(v->{if(!hasStorage()){ensureStoragePermission();return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);});
    }
    private boolean hasStorage(){if(Build.VERSION.SDK_INT>=30)return Environment.isExternalStorageManager();return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
    private void ensureStoragePermission(){if(Build.VERSION.SDK_INT>=30&&!Environment.isExternalStorageManager()){try{Intent i=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}}else if(Build.VERSION.SDK_INT<30&&checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_REQ);}}
    private AppConfig form(){AppConfig c=cfg;c.server=server.getText().toString().trim();c.email=email.getText().toString().trim();c.username=user.getText().toString().trim();c.password=pass.getText().toString();return c;}
    private void setStatus(String s,boolean err){status.setText(s);status.setTextColor(err?color("#991B1B"):color("#174A72"));status.setBackground(bg(err?color("#FEE2E2"):color("#E8F3FB"),null,12));}
    private void save(){try{cfg=form();cfg.save(this);setStatus("تنظیمات ذخیره شد",false);}catch(Exception e){setStatus("خطا: "+e.getMessage(),true);}}
    private void test(){setStatus("در حال تست Documents...",false);new Thread(()->{try(WorldClientDocs wc=new WorldClientDocs(form())){int n=wc.list().size();runOnUiThread(()->setStatus("اتصال Documents موفق — "+n+" فایل SecureShare روی سرور",false));}catch(Exception e){runOnUiThread(()->setStatus("خطا: "+e.getMessage(),true));}}).start();}
    private void syncNow(){if(!hasStorage()){ensureStoragePermission();setStatus("ابتدا مجوز دسترسی فایل‌ها را فعال کن",true);return;}setStatus("در حال همگام‌سازی دستی...",false);new Thread(()->{try{AppConfig c=form();SyncEngine e=new SyncEngine(this,c);e.sync();String s="همگام‌سازی انجام شد — "+e.getResult().summary();runOnUiThread(()->setStatus(s,false));}catch(Exception ex){runOnUiThread(()->setStatus("خطا: "+ex.getMessage(),true));}}).start();}
    private String displayName(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}return "file.bin";}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_FILE&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();try{SyncEngine e=new SyncEngine(this,form());File dst=new File(e.folder(),displayName(u));try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);}setStatus("فایل اضافه شد؛ برای ارسال «همگام‌سازی الآن» را بزن",false);}catch(Exception ex){setStatus("خطا: "+ex.getMessage(),true);}}}
    private void openFolder(){if(!hasStorage()){ensureStoragePermission();return;}try{SyncEngine e=new SyncEngine(this,form());showFolder(e.folder(),e.folder());}catch(Exception ex){setStatus("خطا: "+ex.getMessage(),true);}}
    private void showFolder(File root,File dir){File[] raw=dir.listFiles();if(raw==null)raw=new File[0];Arrays.sort(raw,(a,b)->{if(a.isDirectory()!=b.isDirectory())return a.isDirectory()?-1:1;return a.getName().compareToIgnoreCase(b.getName());});final File[] files=raw;boolean parent=!same(root,dir);String[] labels=new String[files.length+(parent?1:0)];int off=0;if(parent){labels[0]="⬆  پوشه بالا";off=1;}for(int i=0;i<files.length;i++)labels[i+off]=(files[i].isDirectory()?"📁  ":"📄  ")+files[i].getName()+(files[i].isFile()?"  ("+human(files[i].length())+")":"");new AlertDialog.Builder(this).setTitle(dir.equals(root)?"Download / SecureShare":dir.getName()).setItems(labels,(d,w)->{if(parent&&w==0){showFolder(root,dir.getParentFile());return;}File f=files[w-(parent?1:0)];if(f.isDirectory())showFolder(root,f);else actions(root,dir,f);}).setNegativeButton("بستن",null).show();}
    private void actions(File root,File dir,File f){new AlertDialog.Builder(this).setTitle(f.getName()).setItems(new String[]{"باز کردن","حذف فایل"},(d,w)->{if(w==0)openFile(root,f);else new AlertDialog.Builder(this).setTitle("حذف فایل").setMessage("فایل حذف شود؟ حذف از Documents در همگام‌سازی دستی بعدی انجام می‌شود.").setPositiveButton("حذف",(x,y)->{if(f.delete()){setStatus("فایل حذف شد؛ برای حذف از Documents همگام‌سازی را بزن",false);showFolder(root,dir);}else setStatus("حذف فایل انجام نشد",true);}).setNegativeButton("انصراف",null).show();}).setNegativeButton("انصراف",null).show();}
    private boolean same(File a,File b){try{return a.getCanonicalPath().equals(b.getCanonicalPath());}catch(Exception e){return a.equals(b);}}
    private void openFile(File root,File f){try{Uri u=SecureShareFileProvider.uriFor(this,root,f);String ext=MimeTypeMap.getFileExtensionFromUrl(f.getName());String mime=ext==null?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.US));if(mime==null)mime="application/octet-stream";Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(u,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(this,"خطا در بازکردن فایل: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String human(long n){if(n<1024)return n+" B";double v=n/1024.0;String[] u={"KB","MB","GB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return new DecimalFormat("0.#").format(v)+" "+u[i];}
}
