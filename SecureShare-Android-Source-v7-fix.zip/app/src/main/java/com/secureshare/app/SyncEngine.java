package com.secureshare.app;

import android.content.Context;
import android.os.Environment;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public final class SyncEngine {
    public static final class FileState {
        String hash=""; long modified=0,size=0;
        FileState(){}
        FileState(String h,long m,long s){hash=h;modified=m;size=s;}
    }
    public static final class RemoteFile {
        WorldClientDocs.RemoteDocument doc; FileState meta; String path; String sender; byte[] data;
    }
    public static final class Result {
        public int uploaded,downloaded,deletedLocal,deletedRemote,conflicts;
        public String summary(){String s="آپلود "+uploaded+" | دانلود "+downloaded+" | حذف محلی "+deletedLocal+" | حذف سرور "+deletedRemote;if(conflicts>0)s+=" | تداخل "+conflicts;return s;}
    }

    private final Context ctx;
    private final AppConfig cfg;
    private final File root;
    private final File stateFile;
    private final JSONObject state;
    private Result result=new Result();

    public SyncEngine(Context ctx,AppConfig cfg)throws Exception{
        this.ctx=ctx.getApplicationContext();this.cfg=cfg;
        root=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SecureShare");
        if(!root.exists()&&!root.mkdirs())throw new IOException("ساخت پوشه Download/SecureShare ممکن نشد");
        File meta=new File(ctx.getFilesDir(),"secureshare_v6");if(!meta.exists())meta.mkdirs();stateFile=new File(meta,"state-documents.json");state=loadState();
    }
    public File folder(){return root;}
    public Result getResult(){return result;}
    private JSONObject loadState(){try{if(stateFile.exists())return new JSONObject(new String(Files.readAllBytes(stateFile.toPath()),StandardCharsets.UTF_8));}catch(Exception ignored){}return new JSONObject();}
    private void saveState(){try(FileOutputStream o=new FileOutputStream(stateFile)){o.write(state.toString().getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static FileState stat(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)d.update(b,0,n);}return new FileState(hex(d.digest()),f.lastModified(),f.length());}
    private String rel(File f)throws Exception{String rp=root.getCanonicalPath(),fp=f.getCanonicalPath();if(!fp.startsWith(rp+File.separator))throw new IOException("Unsafe path");return fp.substring(rp.length()+1).replace(File.separatorChar,'/');}
    private File safe(String rel)throws Exception{if(rel.startsWith("/")||rel.contains(":")||rel.contains("../")||rel.equals(".."))throw new IOException("Unsafe path");File f=new File(root,rel.replace('/',File.separatorChar));String rp=root.getCanonicalPath(),fp=f.getCanonicalPath();if(!fp.startsWith(rp+File.separator))throw new IOException("Unsafe path");return f;}
    private void walk(File d,List<File> out){File[] a=d.listFiles();if(a==null)return;for(File f:a){if(f.isDirectory())walk(f,out);else out.add(f);}}
    private Map<String,FileState> local()throws Exception{Map<String,FileState> m=new HashMap<>();List<File> fs=new ArrayList<>();walk(root,fs);for(File f:fs)m.put(rel(f),stat(f));return m;}
    private FileState old(String p){JSONObject o=state.optJSONObject(p);if(o==null)return null;return new FileState(o.optString("hash",""),o.optLong("modified",0),o.optLong("size",0));}
    private void putState(JSONObject target,String p,FileState s)throws Exception{JSONObject o=new JSONObject();o.put("hash",s.hash);o.put("modified",s.modified);o.put("size",s.size);target.put(p,o);}

    public synchronized void sync()throws Exception{
        result=new Result();
        try(WorldClientDocs wc=new WorldClientDocs(cfg)){
            Map<String,RemoteFile> remote=remote(wc);Map<String,FileState> local=local();
            Set<String> paths=new TreeSet<>();paths.addAll(remote.keySet());paths.addAll(local.keySet());Iterator<String> it=state.keys();while(it.hasNext())paths.add(it.next());
            JSONObject next=new JSONObject();
            for(String p:paths){RemoteFile r=remote.get(p);FileState l=local.get(p),o=old(p);boolean had=o!=null;
                if(r!=null&&l!=null){
                    if(r.meta.hash.equals(l.hash)){putState(next,p,l);continue;}
                    if(had&&l.hash.equals(o.hash)&&!r.meta.hash.equals(o.hash)){writeRemote(p,r);putState(next,p,r.meta);result.downloaded++;continue;}
                    if(had&&r.meta.hash.equals(o.hash)&&!l.hash.equals(o.hash)){replaceRemote(wc,p,r.doc,l);putState(next,p,l);result.uploaded++;continue;}
                    writeConflict(p,r);result.conflicts++;replaceRemote(wc,p,r.doc,l);putState(next,p,l);result.uploaded++;
                }else if(r!=null){
                    if(had){wc.delete(r.doc);result.deletedRemote++;}
                    else{writeRemote(p,r);putState(next,p,r.meta);result.downloaded++;}
                }else if(l!=null){
                    if(had){File f=safe(p);if(f.exists())f.delete();result.deletedLocal++;}
                    else{upload(wc,p,l);putState(next,p,l);result.uploaded++;}
                }
            }
            while(state.keys().hasNext())break;
            // replace state object contents
            List<String> oldKeys=new ArrayList<>();Iterator<String> oi=state.keys();while(oi.hasNext())oldKeys.add(oi.next());for(String k:oldKeys)state.remove(k);Iterator<String> ni=next.keys();while(ni.hasNext()){String k=ni.next();state.put(k,next.get(k));}saveState();
        }
    }
    private Map<String,RemoteFile> remote(WorldClientDocs wc)throws Exception{Map<String,RemoteFile> out=new HashMap<>();for(WorldClientDocs.RemoteDocument d:wc.list()){byte[] enc=wc.download(d.id);byte[] plain;
            try{
                plain=CryptoUtil.decrypt(AppConfig.sharedPassphrase(cfg.password),enc);
            }catch(Exception primary){
                try{ plain=CryptoUtil.decrypt(AppConfig.legacyPassphrase(cfg.password),enc); }
                catch(Exception legacy){ continue; }
            }
            Protocol.Parsed p;try{p=Protocol.unpack(plain);}catch(Exception x){continue;}if(!"file".equals(p.header.op)||p.header.path.isEmpty())continue;RemoteFile rf=new RemoteFile();rf.doc=d;rf.path=p.header.path;rf.sender=p.header.sender;rf.data=p.data;rf.meta=new FileState(p.header.hash,p.header.modified,p.header.size);RemoteFile prev=out.get(rf.path);if(prev==null||d.id>prev.doc.id)out.put(rf.path,rf);}return out;}
    private void upload(WorldClientDocs wc,String path,FileState s)throws Exception{File f=safe(path);byte[] data=Files.readAllBytes(f.toPath());Protocol.Header h=new Protocol.Header();h.op="file";h.path=path;h.hash=s.hash;h.modified=s.modified;h.size=s.size;h.sender=cfg.deviceId;h.fileId=UUID.randomUUID().toString().replace("-","");byte[] pkt=Protocol.pack(h,data);byte[] enc=CryptoUtil.encrypt(AppConfig.sharedPassphrase(cfg.password),pkt);wc.upload(WorldClientDocs.remoteNameForPath(path,cfg.password),enc);}
    private void replaceRemote(WorldClientDocs wc,String path,WorldClientDocs.RemoteDocument d,FileState s)throws Exception{wc.delete(d);upload(wc,path,s);}
    private void writeRemote(String path,RemoteFile r)throws Exception{File dest=safe(path);if(dest.getParentFile()!=null)dest.getParentFile().mkdirs();File tmp=new File(dest.getPath()+".secureshare.tmp");try(FileOutputStream o=new FileOutputStream(tmp)){o.write(r.data);}FileState st=stat(tmp);if(!st.hash.equals(r.meta.hash)){tmp.delete();throw new IOException("Remote file hash mismatch");}if(dest.exists())dest.delete();if(!tmp.renameTo(dest))throw new IOException("Cannot replace file");if(r.meta.modified>0)dest.setLastModified(r.meta.modified);}
    private void writeConflict(String path,RemoteFile r)throws Exception{File dest=safe(path);String n=dest.getName();int dot=n.lastIndexOf('.');String b=dot>0?n.substring(0,dot):n,e=dot>0?n.substring(dot):"";String t=new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());File c=new File(dest.getParentFile(),b+" (remote conflict "+t+")"+e);if(c.getParentFile()!=null)c.getParentFile().mkdirs();try(FileOutputStream o=new FileOutputStream(c)){o.write(r.data);}}
}
