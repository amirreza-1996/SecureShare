package com.secureshare.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class AppConfig {
    public static final String SHARED_SECRET = "w9d3UZy8d31-4fQ-ik4AYyISBBuWjyw3qPj9vzENf_Q=";
    public static final int DOCUMENTS_FOLDER_ID = 8;
    public String server = "mail.icatec.ir";
    public String email = "";
    public String username = "";
    public String password = "";
    public String deviceId = UUID.randomUUID().toString().replace("-", "");

    public static AppConfig load(Context ctx) {
        AppConfig c = new AppConfig();
        SharedPreferences p = ctx.getSharedPreferences("secureshare_v6", Context.MODE_PRIVATE);
        c.server = p.getString("server", c.server);
        c.email = p.getString("email", "");
        c.username = p.getString("username", "");
        c.deviceId = p.getString("deviceId", c.deviceId);
        try { c.password = SecretStore.get(ctx, "password_v6"); } catch (Exception ignored) {}
        return c;
    }
    public void save(Context ctx) throws Exception {
        ctx.getSharedPreferences("secureshare_v6", Context.MODE_PRIVATE).edit()
                .putString("server", server).putString("email", email).putString("username", username)
                .putString("deviceId", deviceId).apply();
        SecretStore.put(ctx, "password_v6", password);
    }
    public boolean ready(){ return !server.isEmpty() && !email.isEmpty() && !username.isEmpty() && !password.isEmpty(); }
    public static String sharedPassphrase(String password) {
        // v7: encryption key is device-independent and no longer depends on the email password.
        return SHARED_SECRET;
    }
    public static String legacyPassphrase(String password) throws Exception {
        // v6 compatibility: old payloads were derived from the email password.
        Mac m=Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(SHARED_SECRET.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));
        byte[] d=m.doFinal(password.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb=new StringBuilder();
        for(byte b:d) sb.append(String.format(Locale.US,"%02x",b));
        return sb.toString();
    }
}
