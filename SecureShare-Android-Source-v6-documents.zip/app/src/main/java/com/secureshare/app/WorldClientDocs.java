package com.secureshare.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;

public final class WorldClientDocs implements Closeable {
    public static final class RemoteDocument {
        public int id;
        public String name;
        public String deleteUrl;
        public RemoteDocument(int id,String name,String deleteUrl){this.id=id;this.name=name;this.deleteUrl=deleteUrl;}
    }

    private final AppConfig cfg;
    private final CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
    private final String base;
    private String session = "";

    private static final Pattern SESSION_RE = Pattern.compile("(?i)(?:[?&]|&amp;)Session=([A-Za-z0-9_-]+)");
    private static final Pattern ROW_RE = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern DOWNLOAD_RE = Pattern.compile("(?i)(?:[?&]|&amp;)Download=(\\d+)");
    private static final Pattern SECURE_NAME_RE = Pattern.compile("SS_[0-9a-fA-F]{40}\\.bin");
    private static final Pattern HREF_RE = Pattern.compile("(?is)href\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern URL_IN_JS_RE = Pattern.compile("(?i)(WorldClient\\.dll\\?[^\\\"'\\s)]+)");

    public WorldClientDocs(AppConfig cfg) throws Exception {
        this.cfg = cfg;
        this.base = normalizeBase(cfg.server);
        CookieHandler.setDefault(cookies);
        login();
    }

    private static String normalizeBase(String s){
        s=s.trim(); while(s.endsWith("/"))s=s.substring(0,s.length()-1);
        if(!s.toLowerCase(Locale.US).startsWith("http://")&&!s.toLowerCase(Locale.US).startsWith("https://"))s="https://"+s;
        return s;
    }
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[65536];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toByteArray();}
    private static String bodyText(HttpURLConnection c)throws Exception{InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(in==null)return "";return new String(readAll(in),StandardCharsets.UTF_8);}
    private HttpURLConnection open(String u,String method)throws Exception{
        URL url=new URL(u);HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(true);c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setRequestMethod(method);c.setRequestProperty("User-Agent","SecureShare/2.0");return c;
    }
    private void login()throws Exception{
        String u=base+"/WorldClient.dll?View=Main&User="+enc(cfg.username)+"&Password="+enc(cfg.password);
        HttpURLConnection c=open(u,"GET");String body=bodyText(c);int code=c.getResponseCode();String finalUrl=c.getURL().toString();c.disconnect();
        if(code<200||code>=400)throw new IOException("ورود Webmail: HTTP "+code);
        Matcher m=SESSION_RE.matcher(finalUrl);if(m.find())session=m.group(1);
        if(session.isEmpty()){m=SESSION_RE.matcher(body);if(m.find())session=m.group(1);}
        if(session.isEmpty())throw new IOException("ورود Webmail انجام نشد؛ Session دریافت نشد");
    }
    public void close(){try{if(!session.isEmpty()){HttpURLConnection c=open(base+"/WorldClient.dll?Session="+enc(session)+"&View=LogOut","GET");c.getResponseCode();c.disconnect();}}catch(Exception ignored){}}

    private String listHtml()throws Exception{
        String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID;
        HttpURLConnection c=open(u,"GET");String b=bodyText(c);int code=c.getResponseCode();c.disconnect();if(code!=200)throw new IOException("Documents list: HTTP "+code);return b;
    }
    private static String htmlUnescape(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">");}
    public List<RemoteDocument> list()throws Exception{
        String html=listHtml();List<RemoteDocument> out=new ArrayList<>();Set<Integer> seen=new HashSet<>();Matcher rm=ROW_RE.matcher(html);
        while(rm.find()){
            String row=rm.group(1);Matcher dm=DOWNLOAD_RE.matcher(row);if(!dm.find())continue;int id=Integer.parseInt(dm.group(1));Matcher nm=SECURE_NAME_RE.matcher(row);if(!nm.find())continue;String name=nm.group();String del="";
            Matcher hm=HREF_RE.matcher(row);while(hm.find()){
                String h=htmlUnescape(hm.group(1));String l=h.toLowerCase(Locale.US);
                if((l.contains("delete")||l.contains("remove"))&&h.contains(Integer.toString(id))){del=h;break;}
                if(l.startsWith("javascript:")){Matcher jm=URL_IN_JS_RE.matcher(h);if(jm.find()){String cand=htmlUnescape(jm.group(1));String lc=cand.toLowerCase(Locale.US);if((lc.contains("delete")||lc.contains("remove"))&&cand.contains(Integer.toString(id))){del=cand;break;}}}
            }
            out.add(new RemoteDocument(id,name,del));seen.add(id);
        }
        Matcher dm=DOWNLOAD_RE.matcher(html);while(dm.find()){
            int id=Integer.parseInt(dm.group(1));if(seen.contains(id))continue;int a=Math.max(0,dm.start()-1200),b=Math.min(html.length(),dm.end()+1200);String chunk=html.substring(a,b);Matcher nm=SECURE_NAME_RE.matcher(chunk);if(nm.find())out.add(new RemoteDocument(id,nm.group(),""));
        }
        return out;
    }
    public byte[] download(int id)throws Exception{
        String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Download="+id;
        HttpURLConnection c=open(u,"GET");int code=c.getResponseCode();if(code!=200){c.disconnect();throw new IOException("دانلود Document "+id+": HTTP "+code);}byte[] b=readAll(c.getInputStream());c.disconnect();return b;
    }
    public void upload(String name,byte[] data)throws Exception{
        String boundary="----SecureShare"+System.nanoTime();
        String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&ReturnJavaScript=Yes&Upload=Yes&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&GETJSON=Yes&ContentType=javascript";
        HttpURLConnection c=open(u,"POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        OutputStream out=c.getOutputStream();String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\"Attachment:0\"; filename=\""+name+"\"\r\nContent-Type: application/octet-stream\r\n\r\n";out.write(head.getBytes(StandardCharsets.UTF_8));out.write(data);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();out.close();int code=c.getResponseCode();if(c.getInputStream()!=null)try{readAll(c.getInputStream());}catch(Exception ignored){}c.disconnect();if(code<200||code>=300)throw new IOException("آپلود Documents: HTTP "+code);
    }
    private URL resolve(String raw)throws Exception{
        raw=htmlUnescape(raw.trim());if(raw.toLowerCase(Locale.US).startsWith("javascript:")){Matcher m=URL_IN_JS_RE.matcher(raw);if(!m.find())return null;raw=m.group(1);}return new URL(new URL(base+"/"),raw);
    }
    private boolean tryDeleteUrl(String raw)throws Exception{URL u=resolve(raw);if(u==null)return false;String s=u.toString();if(!s.toLowerCase(Locale.US).contains("session=")){s+=(s.contains("?")?"&":"?")+"Session="+enc(session);}HttpURLConnection c=open(s,"GET");int code=c.getResponseCode();try{if(c.getInputStream()!=null)readAll(c.getInputStream());}catch(Exception ignored){}c.disconnect();return code>=200&&code<400;}
    private boolean existsId(int id)throws Exception{for(RemoteDocument d:list())if(d.id==id)return true;return false;}
    public void delete(RemoteDocument d)throws Exception{
        if(d.deleteUrl!=null&&!d.deleteUrl.isEmpty()){tryDeleteUrl(d.deleteUrl);if(!existsId(d.id))return;}
        String[] cand={
            base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Delete="+d.id,
            base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&DeleteDocument="+d.id,
            base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Remove="+d.id
        };
        for(String s:cand){tryDeleteUrl(s);if(!existsId(d.id))return;}
        throw new IOException("حذف Document "+d.id+" توسط نسخه فعلی WorldClient شناسایی نشد");
    }
    public static String remoteNameForPath(String path,String password)throws Exception{
        Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(AppConfig.sharedPassphrase(password).getBytes(StandardCharsets.UTF_8),"HmacSHA256"));byte[] d=m.doFinal(path.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder("SS_");for(int i=0;i<20;i++)s.append(String.format(Locale.US,"%02x",d[i]));return s+".bin";
    }
}
