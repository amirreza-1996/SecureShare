package com.secureshare.app;

import android.content.*;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import java.io.*;
import java.util.Locale;

public final class SecureShareFileProvider extends ContentProvider {
    public static Uri uriFor(Context ctx,File root,File file)throws Exception{
        String rp=root.getCanonicalPath(),fp=file.getCanonicalPath();
        if(!fp.startsWith(rp+File.separator))throw new FileNotFoundException("Unsafe path");
        String rel=fp.substring(rp.length()+1).replace(File.separatorChar,'/');
        return new Uri.Builder().scheme("content").authority(ctx.getPackageName()+".files").encodedPath("/"+Uri.encode(rel,"/")).build();
    }
    private File root(){File base=getContext().getExternalFilesDir(null);if(base==null)base=getContext().getFilesDir();return new File(base,"SecureShare");}
    private File resolve(Uri uri)throws FileNotFoundException{
        String p=uri.getEncodedPath();if(p==null)throw new FileNotFoundException();String rel=Uri.decode(p.startsWith("/")?p.substring(1):p);
        try{File r=root(),f=new File(r,rel.replace('/',File.separatorChar));String rp=r.getCanonicalPath(),fp=f.getCanonicalPath();if(!fp.startsWith(rp+File.separator))throw new FileNotFoundException("Unsafe path");if(!f.exists()||!f.isFile())throw new FileNotFoundException(f.getPath());return f;}catch(IOException e){throw new FileNotFoundException(e.getMessage());}
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){try{File f=resolve(uri);String n=f.getName();int d=n.lastIndexOf('.');if(d>=0){String m=MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substring(d+1).toLowerCase(Locale.US));if(m!=null)return m;}}catch(Exception ignored){}return "application/octet-stream";}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){try{File f=resolve(uri);String[] cols=projection!=null?projection:new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};MatrixCursor c=new MatrixCursor(cols,1);MatrixCursor.RowBuilder r=c.newRow();for(String col:cols){if(OpenableColumns.DISPLAY_NAME.equals(col))r.add(f.getName());else if(OpenableColumns.SIZE.equals(col))r.add(f.length());else r.add(null);}return c;}catch(Exception e){return null;}}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{if(!"r".equals(mode))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
}
