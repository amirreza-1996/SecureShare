package com.secureshare.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class WorldClientDocs implements Closeable {
    public static final class RemoteDocument {
        public int id;
        public String name;
        public String deleteUrl;
        public RemoteDocument(int id,String name,String deleteUrl){this.id=id;this.name=name;this.deleteUrl=deleteUrl;}
    }

    private final AppConfig cfg;
    private final CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
    private final String base;
    private String session = "";

    private static final Pattern SESSION_RE=Pattern.compile("(?i)(?:[?&]|&amp;)Session=([A-Za-z0-9_-]+)");
    private static final Pattern ROW_RE=Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern DOWNLOAD_RE=Pattern.compile("(?i)(?:[?&]|&amp;|%26)Download(?:=|%3D)(\\d+)");
    private static final Pattern SECURE_NAME_RE=Pattern.compile("(?i)(?:SS_[0-9a-f]{40}|SSV9_[0-9a-f]{40}|SSV9D_[0-9a-f]{40}|SSV10M_[0-9a-f]{40})\\.bin");
    private static final Pattern LINK_RE=Pattern.compile("(?is)(?:href|src|action|onclick)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern URL_IN_JS_RE=Pattern.compile("(?i)(WorldClient\\.dll\\?[^\\\"'\\s)]+)");
    private static final Pattern JSON_ID_RE=Pattern.compile("(?i)\\\"[^\\\"]*(?:id|download)[^\\\"]*\\\"\\s*:\\s*\\\"?(\\d{1,10})\\\"?");
    private static final Pattern ATTR_ID_RE=Pattern.compile("(?i)(?:data-(?:document-)?id|documentid|docid)\\s*=\\s*[\\\"']?(\\d{1,10})");
    private static final Pattern QUERY_ID_RE=Pattern.compile("(?i)(?:[?&]|&amp;)(?:DocumentID|DocID|FileID|ID)=(\\d{1,10})");
    private static final Pattern FORM_RE=Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form>");
    private static final Pattern INPUT_RE=Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern BUTTON_RE=Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button>");
    private static final Pattern ANY_URL_RE=Pattern.compile("(?i)(?:/)?WorldClient\\.dll\\?[^\\\"'<>\\s)]+");

    public WorldClientDocs(AppConfig cfg)throws Exception{
        this.cfg=cfg;
        this.base=normalizeBase(cfg.server);
        CookieHandler.setDefault(cookies);
        login();
    }

    private static String normalizeBase(String s){
        s=s.trim(); while(s.endsWith("/"))s=s.substring(0,s.length()-1);
        String l=s.toLowerCase(Locale.US); if(!l.startsWith("http://")&&!l.startsWith("https://"))s="https://"+s;
        return s;
    }
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[65536];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toByteArray();}
    private static String bodyText(HttpURLConnection c)throws Exception{InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(in==null)return "";return new String(readAll(in),StandardCharsets.UTF_8);}
    private HttpURLConnection open(String u,String method)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setInstanceFollowRedirects(true);c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setRequestMethod(method);
        c.setRequestProperty("User-Agent","SecureShare/2.2");c.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");
        return c;
    }
    private static String nc(){return Long.toString(System.nanoTime());}

    private void login()throws Exception{
        String u=base+"/WorldClient.dll?View=Main&User="+enc(cfg.username)+"&Password="+enc(cfg.password)+"&_ssnc="+nc();
        HttpURLConnection c=open(u,"GET");String body=bodyText(c);int code=c.getResponseCode();String finalUrl=c.getURL().toString();c.disconnect();
        if(code<200||code>=400)throw new IOException("ورود Webmail: HTTP "+code);
        Matcher m=SESSION_RE.matcher(finalUrl);if(m.find())session=m.group(1);
        if(session.isEmpty()){m=SESSION_RE.matcher(body);if(m.find())session=m.group(1);}
        if(session.isEmpty())throw new IOException("ورود Webmail انجام نشد؛ Session دریافت نشد");
    }
    @Override public void close(){try{if(!session.isEmpty()){HttpURLConnection c=open(base+"/WorldClient.dll?Session="+enc(session)+"&View=LogOut&_ssnc="+nc(),"GET");c.getResponseCode();c.disconnect();}}catch(Exception ignored){}}

    private String listUrl(String extra)throws Exception{
        return base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&_ssnc="+nc()+(extra==null||extra.isEmpty()?"":"&"+extra);
    }
    private String getText(String u)throws Exception{
        HttpURLConnection c=open(u,"GET");String b=bodyText(c);int code=c.getResponseCode();c.disconnect();
        if(code<200||code>=400)throw new IOException("Documents list: HTTP "+code);return b;
    }
    private List<String> listBodies()throws Exception{
        String[] extras={"","GETJSON=Yes","GETJSON=Yes&ContentType=json","ReturnJavaScript=Yes&GETJSON=Yes&ContentType=javascript","Search=SS","SearchText=SS"};
        LinkedHashSet<String> bodies=new LinkedHashSet<>();Exception first=null;
        for(String x:extras){try{bodies.add(getText(listUrl(x)));}catch(Exception e){if(first==null)first=e;}}
        if(bodies.isEmpty()&&first!=null)throw first;return new ArrayList<>(bodies);
    }
    private static String htmlUnescape(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">");}
    private static void addIds(Pattern p,String s,Set<Integer> ids){Matcher m=p.matcher(s);while(m.find()){try{int id=Integer.parseInt(m.group(1));if(id>0)ids.add(id);}catch(Exception ignored){}}}
    private static Set<Integer> extractIds(String body){
        LinkedHashSet<Integer> ids=new LinkedHashSet<>();ArrayList<String> vars=new ArrayList<>();vars.add(body);vars.add(htmlUnescape(body));
        try{vars.add(URLDecoder.decode(body,"UTF-8"));}catch(Exception ignored){}
        for(String s:vars){addIds(DOWNLOAD_RE,s,ids);addIds(JSON_ID_RE,s,ids);addIds(ATTR_ID_RE,s,ids);addIds(QUERY_ID_RE,s,ids);}
        ids.remove(AppConfig.DOCUMENTS_FOLDER_ID);return ids;
    }

    public List<RemoteDocument> list()throws Exception{
        LinkedHashMap<Integer,RemoteDocument> docs=new LinkedHashMap<>();
        for(String html:listBodies()){
            Matcher rm=ROW_RE.matcher(html);
            while(rm.find()){
                String row=rm.group(1);Set<Integer> ids=extractIds(row);if(ids.isEmpty())continue;
                String name="";Matcher nm=SECURE_NAME_RE.matcher(row);if(nm.find())name=nm.group();
                String del="";Matcher lm=LINK_RE.matcher(row);
                while(lm.find()){
                    String h=htmlUnescape(lm.group(1));String l=h.toLowerCase(Locale.US);
                    if(l.contains("delete")||l.contains("remove")||l.contains("حذف")){del=h;break;}
                    Matcher jm=URL_IN_JS_RE.matcher(h);if(jm.find()){String cand=htmlUnescape(jm.group(1));String lc=cand.toLowerCase(Locale.US);if(lc.contains("delete")||lc.contains("remove")){del=cand;break;}}
                }
                for(int id:ids){RemoteDocument d=docs.get(id);if(d==null)d=new RemoteDocument(id,"","");if(d.name.isEmpty())d.name=name;if(d.deleteUrl.isEmpty())d.deleteUrl=del;docs.put(id,d);}
            }
            for(int id:extractIds(html))if(!docs.containsKey(id))docs.put(id,new RemoteDocument(id,"",""));
        }
        ArrayList<Integer> ids=new ArrayList<>(docs.keySet());Collections.sort(ids);if(ids.size()>500)ids=new ArrayList<>(ids.subList(ids.size()-500,ids.size()));
        ArrayList<RemoteDocument> out=new ArrayList<>();for(int id:ids)out.add(docs.get(id));return out;
    }

    public byte[] download(int id)throws Exception{
        String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Download="+id+"&_ssnc="+nc();
        HttpURLConnection c=open(u,"GET");int code=c.getResponseCode();if(code!=200){c.disconnect();throw new IOException("دانلود Document "+id+": HTTP "+code);}byte[] b=readAll(c.getInputStream());c.disconnect();return b;
    }

    public void upload(String name,byte[] data)throws Exception{
        String boundary="----SecureShare"+System.nanoTime();
        String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&ReturnJavaScript=Yes&Upload=Yes&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&GETJSON=Yes&ContentType=javascript&_ssnc="+nc();
        HttpURLConnection c=open(u,"POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        OutputStream out=c.getOutputStream();String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\"Attachment:0\"; filename=\""+name+"\"\r\nContent-Type: application/octet-stream\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));out.write(data);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();out.close();
        int code=c.getResponseCode();try{bodyText(c);}catch(Exception ignored){}c.disconnect();if(code<200||code>=300)throw new IOException("آپلود Documents: HTTP "+code);
    }

    private URL resolve(String raw)throws Exception{
        raw=htmlUnescape(raw.trim());
        if(raw.toLowerCase(Locale.US).startsWith("javascript:")){Matcher m=URL_IN_JS_RE.matcher(raw);if(!m.find())return null;raw=m.group(1);}
        return new URL(new URL(base+"/"),raw);
    }
    private boolean payloadExists(int id){try{byte[] b=download(id);return b.length>=4&&b[0]=='S'&&b[1]=='S'&&b[2]=='E'&&b[3]=='1';}catch(Exception e){return false;}}
    private void tryGetDelete(String raw){
        try{URL u=resolve(raw);if(u==null)return;String s=u.toString();if(!s.toLowerCase(Locale.US).contains("session="))s+=(s.contains("?")?"&":"?")+"Session="+enc(session);s+=(s.contains("?")?"&":"?")+"_ssnc="+nc();HttpURLConnection c=open(s,"GET");try{bodyText(c);}catch(Exception ignored){}c.disconnect();}catch(Exception ignored){}
    }
    private static String attrValue(String attrs,String name){
        Pattern p=Pattern.compile("(?is)\\b"+Pattern.quote(name)+"\\s*=\\s*(?:[\\\"']([^\\\"']*)[\\\"']|([^\\s>]+))");Matcher m=p.matcher(attrs);
        if(m.find()){String a=m.group(1);if(a!=null)return htmlUnescape(a);String b=m.group(2);return b==null?"":htmlUnescape(b);}return "";
    }
    private static boolean hasDeleteWord(String s){String l=htmlUnescape(s).toLowerCase(Locale.US);return l.contains("delete")||l.contains("remove")||l.contains("حذف");}
    private static boolean containsDocRef(String s,RemoteDocument d){
        String id=Integer.toString(d.id);return s.contains("Download="+id)||s.contains("Download%3D"+id)||s.contains("DocumentID="+id)||s.contains("DocID="+id)||s.contains("value=\""+id+"\"")||s.contains("value='"+id+"'")||(!d.name.isEmpty()&&s.contains(d.name));
    }
    private void submitForm(String method,String action,LinkedHashMap<String,String> fields){
        try{
            if(!fields.containsKey("Session"))fields.put("Session",session);if(!fields.containsKey("View"))fields.put("View","DocumentList");if(!fields.containsKey("FolderID"))fields.put("FolderID",Integer.toString(AppConfig.DOCUMENTS_FOLDER_ID));fields.put("_ssnc",nc());
            if(action==null||action.isEmpty())action="/WorldClient.dll";URL u=resolve(action);if(u==null)return;
            StringBuilder b=new StringBuilder();for(Map.Entry<String,String> e:fields.entrySet()){if(b.length()>0)b.append('&');b.append(enc(e.getKey())).append('=').append(enc(e.getValue()==null?"":e.getValue()));}
            if("GET".equalsIgnoreCase(method)){String s=u.toString()+(u.toString().contains("?")?"&":"?")+b;tryGetDelete(s);return;}
            HttpURLConnection c=open(u.toString(),"POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream o=c.getOutputStream()){o.write(b.toString().getBytes(StandardCharsets.UTF_8));}try{bodyText(c);}catch(Exception ignored){}c.disconnect();
        }catch(Exception ignored){}
    }
    private void tryPageDelete(RemoteDocument d){
        try{
            String html=getText(listUrl(""));
            Matcher um=ANY_URL_RE.matcher(html);while(um.find()){String u=htmlUnescape(um.group());if(containsDocRef(u,d)&&hasDeleteWord(u)){tryGetDelete(u);if(!payloadExists(d.id))return;}}
            Matcher fm=FORM_RE.matcher(html);
            while(fm.find()){
                String attrs=fm.group(1),inner=fm.group(2),whole=attrs+" "+inner;if(!containsDocRef(whole,d)||!hasDeleteWord(whole))continue;
                LinkedHashMap<String,String> fields=new LinkedHashMap<>();boolean matchedId=false,deleteControl=false;
                Matcher im=INPUT_RE.matcher(inner);while(im.find()){
                    String a=im.group(1),name=attrValue(a,"name"),val=attrValue(a,"value"),typ=attrValue(a,"type").toLowerCase(Locale.US);if(name.isEmpty())continue;
                    if(val.equals(Integer.toString(d.id))){fields.put(name,val);matchedId=true;continue;}
                    if("hidden".equals(typ))fields.put(name,val);
                    if(hasDeleteWord(a+" "+name+" "+val)&&("submit".equals(typ)||"button".equals(typ)||"image".equals(typ)||name.toLowerCase(Locale.US).contains("delete")||name.toLowerCase(Locale.US).contains("remove"))){fields.put(name,val);deleteControl=true;}
                }
                Matcher bm=BUTTON_RE.matcher(inner);while(bm.find()){String a=bm.group(1),txt=bm.group(2);if(!hasDeleteWord(a+" "+txt))continue;String name=attrValue(a,"name"),val=attrValue(a,"value");if(!name.isEmpty())fields.put(name,val);deleteControl=true;}
                if(!matchedId){fields.put("Selected",Integer.toString(d.id));fields.put("DocumentID",Integer.toString(d.id));}
                if(!deleteControl)fields.put("Delete","Yes");String method=attrValue(attrs,"method");if(method.isEmpty())method="POST";submitForm(method,attrValue(attrs,"action"),fields);if(!payloadExists(d.id))return;
            }
        }catch(Exception ignored){}
    }
    private void tryPostDelete(LinkedHashMap<String,String> m){submitForm("POST","/WorldClient.dll",m);}

    public boolean delete(RemoteDocument d){
        if(!payloadExists(d.id))return true;
        if(d.deleteUrl!=null&&!d.deleteUrl.isEmpty()){tryGetDelete(d.deleteUrl);if(!payloadExists(d.id))return true;}
        tryPageDelete(d);if(!payloadExists(d.id))return true;
        try{
            String[] gets={
                base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Delete="+d.id,
                base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&DeleteDocument="+d.id,
                base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Remove="+d.id,
                base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&DeleteID="+d.id
            };
            for(String g:gets){tryGetDelete(g);if(!payloadExists(d.id))return true;}
        }catch(Exception ignored){}
        String id=Integer.toString(d.id);
        String[][] forms={{"Delete",id},{"DeleteDocument",id},{"Remove",id},{"DeleteID",id},{"Delete","Yes","DocumentID",id},{"Delete","Yes","DocID",id},{"Delete","Yes","ID",id},{"Action","Delete","DocumentID",id},{"Action","Delete","ID",id},{"DeleteSelected","Yes","Selected",id},{"DeleteSelected","Yes","DocumentID",id},{"Delete","Yes","Selected",id},{"Remove","Yes","Selected",id}};
        for(String[] arr:forms){LinkedHashMap<String,String> m=new LinkedHashMap<>();for(int i=0;i+1<arr.length;i+=2)m.put(arr[i],arr[i+1]);tryPostDelete(m);if(!payloadExists(d.id))return true;}
        return false;
    }

    private static String remoteToken(String kind,String path,String hash)throws Exception{
        Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(AppConfig.SHARED_SECRET.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));
        m.update(kind.getBytes(StandardCharsets.UTF_8));m.update((byte)0);m.update(path.getBytes(StandardCharsets.UTF_8));m.update((byte)0);m.update(hash.getBytes(StandardCharsets.UTF_8));byte[] d=m.doFinal();
        StringBuilder s=new StringBuilder();for(int i=0;i<20;i++)s.append(String.format(Locale.US,"%02x",d[i]));return s.toString();
    }
    public static String remoteNameForVersion(String path,String hash)throws Exception{return "SSV9_"+remoteToken("file",path,hash)+".bin";}
    public static String remoteNameForDelete(String path)throws Exception{return "SSV9D_"+remoteToken("delete",path,"")+".bin";}
    public static String remoteNameForManifest()throws Exception{return "SSV10M_"+remoteToken("manifest","__secureshare_manifest_v10__","")+".bin";}
    public static String manifestFileId()throws Exception{return remoteToken("manifest-id","__secureshare_manifest_v10__","");}
    public static String versionFileId(String path,String hash)throws Exception{return remoteToken("version",path,hash);}
    public static String deleteFileId(String path)throws Exception{return remoteToken("delete-id",path,"");}
    public static String remoteNameForPath(String path,String password)throws Exception{return "SS_"+remoteToken("legacy",path,"")+".bin";}
}
