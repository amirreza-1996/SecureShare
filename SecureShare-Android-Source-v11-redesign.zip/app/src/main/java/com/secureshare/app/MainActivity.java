package com.secureshare.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int PICK_FILE=5001, STORAGE_REQ=5002;
    private AppConfig cfg;
    private Typeface iranSans;
    private TextView statusTitle,statusDetail,folderPath,lastSync,mUp,mDown,mDelete,mDup,connectionState;
    private TextView syncButton;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if(Build.VERSION.SDK_INT>=23){getWindow().setStatusBarColor(color("#F6F7FB"));getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);}
        if(Build.VERSION.SDK_INT>=21)getWindow().setNavigationBarColor(color("#F6F7FB"));
        try{iranSans=Typeface.createFromAsset(getAssets(),"IRANSansWeb-Medium.ttf");}catch(Exception ignored){iranSans=Typeface.DEFAULT;}
        cfg=AppConfig.load(this);
        buildHome();
        ensureStoragePermission();
        if(!cfg.ready())new Handler(Looper.getMainLooper()).postDelayed(this::showSettings,350);
    }

    private int dp(int v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,v,getResources().getDisplayMetrics());}
    private int color(String h){return Color.parseColor(h);}
    private GradientDrawable solid(String c,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color(c));g.setCornerRadius(dp(radius));return g;}
    private GradientDrawable bordered(String fill,String stroke,int radius){GradientDrawable g=solid(fill,radius);g.setStroke(dp(1),color(stroke));return g;}
    private GradientDrawable gradient(String a,String b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{color(a),color(b)});g.setCornerRadius(dp(radius));return g;}
    private void applyFont(View v){if(v instanceof TextView)((TextView)v).setTypeface(iranSans);if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)applyFont(g.getChildAt(i));}}
    private TextView text(String s,float size,String c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color(c));t.setTypeface(iranSans);return t;}
    private TextView title(String s,float size,String c){TextView t=text(s,size,c);t.setTypeface(iranSans,Typeface.BOLD);return t;}
    private LinearLayout vbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout hbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout card(){LinearLayout l=vbox();l.setPadding(dp(18),dp(18),dp(18),dp(18));l.setBackground(bordered("#FFFFFF","#E8EBF0",22));l.setElevation(dp(2));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(14);l.setLayoutParams(lp);return l;}
    private TextView button(String label,boolean primary){TextView b=text(label,14,primary?"#FFFFFF":"#344054");b.setGravity(Gravity.CENTER);b.setTypeface(iranSans,Typeface.BOLD);b.setPadding(dp(16),dp(13),dp(16),dp(13));b.setBackground(primary?gradient("#4F46E5","#6366F1",15):bordered("#FFFFFF","#E1E5EC",15));b.setClickable(true);b.setFocusable(true);b.setElevation(primary?dp(2):0);return b;}
    private TextView chip(String label,String fg,String bg){TextView t=text(label,11,fg);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(6),dp(10),dp(6));t.setBackground(solid(bg,99));return t;}
    private LinearLayout quickCard(String top,String bottom){LinearLayout c=vbox();c.setPadding(dp(15),dp(15),dp(15),dp(15));c.setBackground(bordered("#FFFFFF","#E8EBF0",18));c.setElevation(dp(1));TextView a=title(top,14,"#101828");TextView b=text(bottom,10,"#98A2B3");b.setPadding(0,dp(5),0,0);c.addView(a);c.addView(b);return c;}
    private LinearLayout metric(String label,TextView value){LinearLayout c=vbox();c.setPadding(dp(14),dp(13),dp(14),dp(13));c.setBackground(solid("#FAFAFC",16));value.setTextSize(21);value.setTextColor(color("#101828"));value.setTypeface(iranSans,Typeface.BOLD);TextView l=text(label,10,"#98A2B3");l.setPadding(0,dp(3),0,0);c.addView(value);c.addView(l);return c;}
    private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,-2,w);}

    private void buildHome(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setBackgroundColor(color("#F6F7FB"));
        LinearLayout root=vbox();root.setPadding(dp(16),dp(18),dp(16),dp(28));sv.addView(root);

        LinearLayout top=hbox();top.setGravity(Gravity.CENTER_VERTICAL);LinearLayout brand=hbox();
        TextView logo=title("S",18,"#FFFFFF");logo.setGravity(Gravity.CENTER);logo.setBackground(gradient("#4F46E5","#7C3AED",14));LinearLayout.LayoutParams lg=new LinearLayout.LayoutParams(dp(44),dp(44));brand.addView(logo,lg);
        LinearLayout bt=vbox();bt.setPadding(dp(10),0,0,0);bt.addView(title("SecureShare",18,"#101828"));bt.addView(text("DOCUMENTS SYNC",9,"#98A2B3"));brand.addView(bt);top.addView(brand,weight(1));
        TextView settings=button("تنظیمات",false);settings.setTextSize(12);settings.setPadding(dp(13),dp(10),dp(13),dp(10));settings.setOnClickListener(v->showSettings());top.addView(settings,new LinearLayout.LayoutParams(-2,-2));root.addView(top);

        LinearLayout hero=card();hero.setBackground(gradient("#111827","#312E81",24));hero.setPadding(dp(22),dp(22),dp(22),dp(22));LinearLayout.LayoutParams hp=(LinearLayout.LayoutParams)hero.getLayoutParams();hp.topMargin=dp(18);hero.setLayoutParams(hp);
        hero.addView(chip("همگام‌سازی دستی • Documents","#E0E7FF","#343A69"),new LinearLayout.LayoutParams(-2,-2));
        TextView h=title("فایل‌ها بین گوشی و ویندوز",24,"#FFFFFF");h.setPadding(0,dp(17),0,0);hero.addView(h);
        TextView sub=text("هر وقت خودت بخواهی، امن و بدون Sync پس‌زمینه.",12,"#CBD5E1");sub.setPadding(0,dp(6),0,dp(18));hero.addView(sub);
        syncButton=button("همگام‌سازی الآن",true);syncButton.setBackground(solid("#FFFFFF",16));syncButton.setTextColor(color("#312E81"));syncButton.setOnClickListener(v->syncNow());hero.addView(syncButton,new LinearLayout.LayoutParams(-1,-2));
        connectionState=text(cfg.ready()?"آماده برای همگام‌سازی":"تنظیمات اتصال را کامل کن",11,"#CBD5E1");connectionState.setPadding(0,dp(13),0,0);hero.addView(connectionState);root.addView(hero);

        LinearLayout quick=hbox();quick.setGravity(Gravity.FILL_HORIZONTAL);LinearLayout add=quickCard("افزودن فایل","از حافظه گوشی");LinearLayout browse=quickCard("فایل‌های SecureShare","باز کردن پوشه مشترک");LinearLayout.LayoutParams q1=weight(1);q1.setMarginEnd(dp(7));quick.addView(add,q1);LinearLayout.LayoutParams q2=weight(1);q2.setMarginStart(dp(7));quick.addView(browse,q2);root.addView(quick,new LinearLayout.LayoutParams(-1,-2));
        add.setOnClickListener(v->{if(!hasStorage()){ensureStoragePermission();return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);});
        browse.setOnClickListener(v->openFolder());

        LinearLayout activity=card();LinearLayout ah=hbox();LinearLayout at=vbox();at.addView(title("آخرین فعالیت",15,"#101828"));lastSync=text("هنوز همگام نشده",10,"#98A2B3");lastSync.setGravity(Gravity.LEFT);ah.addView(at,weight(1));ah.addView(lastSync,new LinearLayout.LayoutParams(-2,-2));activity.addView(ah);
        LinearLayout stat=borderedRow();statusTitle=title("آماده",14,"#101828");statusDetail=text("برای شروع دکمه همگام‌سازی را بزن.",11,"#667085");statusDetail.setPadding(0,dp(4),0,0);LinearLayout st=vbox();st.addView(statusTitle);st.addView(statusDetail);stat.addView(st,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2);slp.topMargin=dp(14);activity.addView(stat,slp);
        mUp=title("0",21,"#101828");mDown=title("0",21,"#101828");mDelete=title("0",21,"#101828");mDup=title("0",21,"#101828");LinearLayout mr1=hbox();LinearLayout.LayoutParams mm1=weight(1);mm1.setMarginEnd(dp(5));mr1.addView(metric("آپلود",mUp),mm1);LinearLayout.LayoutParams mm2=weight(1);mm2.setMarginStart(dp(5));mr1.addView(metric("دانلود",mDown),mm2);LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.topMargin=dp(10);activity.addView(mr1,rlp);LinearLayout mr2=hbox();LinearLayout.LayoutParams mm3=weight(1);mm3.setMarginEnd(dp(5));mr2.addView(metric("حذف Documents",mDelete),mm3);LinearLayout.LayoutParams mm4=weight(1);mm4.setMarginStart(dp(5));mr2.addView(metric("تکراری رد شده",mDup),mm4);LinearLayout.LayoutParams rlp2=new LinearLayout.LayoutParams(-1,-2);rlp2.topMargin=dp(10);activity.addView(mr2,rlp2);root.addView(activity);

        LinearLayout pathCard=card();LinearLayout ph=hbox();LinearLayout pv=vbox();pv.addView(title("پوشه مشترک",14,"#101828"));folderPath=text("Download/SecureShare",11,"#667085");folderPath.setPadding(0,dp(5),0,0);folderPath.setTextDirection(View.TEXT_DIRECTION_LTR);folderPath.setGravity(Gravity.LEFT);pv.addView(folderPath);ph.addView(pv,weight(1));TextView open=button("باز کردن",false);open.setTextSize(11);open.setOnClickListener(v->openFolder());ph.addView(open,new LinearLayout.LayoutParams(-2,-2));pathCard.addView(ph);root.addView(pathCard);

        setContentView(sv);applyFont(sv);updateFolderPath();
    }

    private LinearLayout borderedRow(){LinearLayout l=vbox();l.setPadding(dp(14),dp(14),dp(14),dp(14));l.setBackground(bordered("#FBFCFE","#ECEEF2",16));return l;}
    private void updateFolderPath(){try{folderPath.setText(new SyncEngine(this,cfg).folder().getAbsolutePath());}catch(Exception e){folderPath.setText("/storage/emulated/0/Download/SecureShare");}}
    private boolean hasStorage(){if(Build.VERSION.SDK_INT>=30)return Environment.isExternalStorageManager();return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
    private void ensureStoragePermission(){if(Build.VERSION.SDK_INT>=30&&!Environment.isExternalStorageManager()){try{startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}}else if(Build.VERSION.SDK_INT<30&&checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_REQ);}}

    private EditText field(LinearLayout root,String label,String value,boolean password,boolean ltr){TextView l=text(label,11,"#667085");l.setPadding(0,dp(11),0,dp(7));root.addView(l);EditText e=new EditText(this);e.setText(value);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(color("#101828"));e.setPadding(dp(13),dp(11),dp(13),dp(11));e.setBackground(bordered("#FBFCFE","#DDE2EA",14));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);if(ltr){e.setTextDirection(View.TEXT_DIRECTION_LTR);e.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);}root.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}

    private void showSettings(){
        final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout wrap=vbox();wrap.setPadding(dp(20),dp(20),dp(20),dp(20));wrap.setBackground(solid("#FFFFFF",24));
        LinearLayout head=hbox();LinearLayout ht=vbox();ht.addView(title("تنظیمات SecureShare",19,"#101828"));ht.addView(text("اتصال Documents و حساب کاربری",10,"#98A2B3"));head.addView(ht,weight(1));TextView close=button("بستن",false);close.setTextSize(11);close.setPadding(dp(12),dp(9),dp(12),dp(9));head.addView(close,new LinearLayout.LayoutParams(-2,-2));wrap.addView(head);
        ScrollView scroll=new ScrollView(this);LinearLayout form=vbox();form.setPadding(0,dp(8),0,dp(4));EditText server=field(form,"Mail Server",cfg.server,false,true);EditText email=field(form,"ایمیل",cfg.email,false,true);EditText user=field(form,"نام کاربری",cfg.username,false,true);EditText pass=field(form,"رمز ایمیل",cfg.password,true,true);TextView note=text("رمز مشترک رمزگذاری داخل برنامه قرار دارد و همگام‌سازی خودکار غیرفعال است.",10,"#667085");note.setPadding(dp(12),dp(12),dp(12),dp(12));note.setBackground(solid("#F8F9FC",14));LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,-2);nlp.topMargin=dp(14);form.addView(note,nlp);scroll.addView(form);LinearLayout.LayoutParams scp=new LinearLayout.LayoutParams(-1,0,1);scp.topMargin=dp(8);wrap.addView(scroll,scp);
        LinearLayout foot=hbox();TextView test=button("تست اتصال",false);TextView save=button("ذخیره تنظیمات",true);LinearLayout.LayoutParams t1=weight(1);t1.setMarginEnd(dp(5));foot.addView(test,t1);LinearLayout.LayoutParams t2=weight(1);t2.setMarginStart(dp(5));foot.addView(save,t2);LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2);flp.topMargin=dp(14);wrap.addView(foot,flp);
        d.setContentView(wrap);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);WindowManager.LayoutParams lp=w.getAttributes();lp.width=(int)(getResources().getDisplayMetrics().widthPixels*.93f);lp.height=(int)(getResources().getDisplayMetrics().heightPixels*.86f);lp.dimAmount=.52f;w.setAttributes(lp);}
        close.setOnClickListener(v->d.dismiss());save.setOnClickListener(v->{try{AppConfig n=configFrom(server,email,user,pass);if(!n.ready())throw new Exception("همه اطلاعات اتصال را کامل کن");n.save(this);cfg=n;connectionState.setText("آماده برای همگام‌سازی");updateFolderPath();setStatus("تنظیمات ذخیره شد","اکنون می‌توانی همگام‌سازی را انجام بده.",false);d.dismiss();}catch(Exception e){Toast.makeText(this,"خطا: "+e.getMessage(),Toast.LENGTH_LONG).show();}});test.setOnClickListener(v->{AppConfig n=configFrom(server,email,user,pass);testConnection(n,test);});
        applyFont(wrap);d.show();
    }
    private AppConfig configFrom(EditText s,EditText e,EditText u,EditText p){AppConfig n=new AppConfig();n.server=s.getText().toString().trim();n.email=e.getText().toString().trim();n.username=u.getText().toString().trim();n.password=p.getText().toString();n.deviceId=cfg.deviceId;return n;}
    private void testConnection(AppConfig c,TextView btn){String old=btn.getText().toString();btn.setText("در حال تست...");btn.setEnabled(false);new Thread(()->{try(WorldClientDocs wc=new WorldClientDocs(c)){int n=wc.list().size();runOnUiThread(()->{btn.setText(old);btn.setEnabled(true);Toast.makeText(this,"اتصال موفق — "+n+" مورد قابل بررسی",Toast.LENGTH_LONG).show();});}catch(Exception ex){runOnUiThread(()->{btn.setText(old);btn.setEnabled(true);Toast.makeText(this,"خطا: "+ex.getMessage(),Toast.LENGTH_LONG).show();});}}).start();}

    private void setStatus(String title,String detail,boolean err){statusTitle.setText(title);statusTitle.setTextColor(color(err?"#B42318":"#101828"));statusDetail.setText(detail);statusDetail.setTextColor(color(err?"#B42318":"#667085"));}
    private void setSyncing(boolean on){syncButton.setEnabled(!on);syncButton.setText(on?"در حال همگام‌سازی...":"همگام‌سازی الآن");connectionState.setText(on?"در حال ارتباط با Documents...":(cfg.ready()?"آماده برای همگام‌سازی":"تنظیمات اتصال را کامل کن"));}
    private void syncNow(){
        if(!cfg.ready()){setStatus("تنظیمات ناقص است","اطلاعات اتصال را از تنظیمات کامل کن.",true);showSettings();return;}
        if(!hasStorage()){ensureStoragePermission();setStatus("مجوز فایل لازم است","دسترسی مدیریت فایل‌ها را برای SecureShare فعال کن.",true);return;}
        setSyncing(true);setStatus("در حال همگام‌سازی","لطفاً چند لحظه صبر کن...",false);
        new Thread(()->{try{SyncEngine e=new SyncEngine(this,cfg);e.sync();SyncEngine.Result r=e.getResult();runOnUiThread(()->{mUp.setText(String.valueOf(r.uploaded));mDown.setText(String.valueOf(r.downloaded));mDelete.setText(String.valueOf(r.deletedRemote));mDup.setText(String.valueOf(r.dedupSkipped));lastSync.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));setStatus("همگام‌سازی انجام شد",r.summary(),false);setSyncing(false);});}catch(Exception ex){runOnUiThread(()->{setStatus("همگام‌سازی ناموفق",ex.getMessage(),true);setSyncing(false);});}}).start();
    }

    private String displayName(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}return "file.bin";}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_FILE&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();try{SyncEngine e=new SyncEngine(this,cfg);File dst=new File(e.folder(),displayName(u));try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);}setStatus("فایل اضافه شد","برای ارسال، همگام‌سازی را بزن.",false);}catch(Exception ex){setStatus("خطا در افزودن فایل",ex.getMessage(),true);}}}
    private void openFolder(){if(!hasStorage()){ensureStoragePermission();return;}try{SyncEngine e=new SyncEngine(this,cfg);showFolder(e.folder(),e.folder());}catch(Exception ex){setStatus("خطا",ex.getMessage(),true);}}
    private void showFolder(File root,File dir){File[] raw=dir.listFiles();if(raw==null)raw=new File[0];Arrays.sort(raw,(a,b)->{if(a.isDirectory()!=b.isDirectory())return a.isDirectory()?-1:1;return a.getName().compareToIgnoreCase(b.getName());});final File[] files=raw;boolean parent=!same(root,dir);String[] labels=new String[files.length+(parent?1:0)];int off=0;if(parent){labels[0]="↑  پوشه بالا";off=1;}for(int i=0;i<files.length;i++)labels[i+off]=(files[i].isDirectory()?"پوشه  •  ":"فایل  •  ")+files[i].getName()+(files[i].isFile()?"  ("+human(files[i].length())+")":"");new AlertDialog.Builder(this).setTitle(dir.equals(root)?"Download / SecureShare":dir.getName()).setItems(labels,(d,w)->{if(parent&&w==0){showFolder(root,dir.getParentFile());return;}File f=files[w-(parent?1:0)];if(f.isDirectory())showFolder(root,f);else actions(root,dir,f);}).setNegativeButton("بستن",null).show();}
    private void actions(File root,File dir,File f){new AlertDialog.Builder(this).setTitle(f.getName()).setItems(new String[]{"باز کردن","حذف فایل"},(d,w)->{if(w==0)openFile(root,f);else new AlertDialog.Builder(this).setTitle("حذف فایل").setMessage("فایل حذف شود؟ حذف از Documents در همگام‌سازی دستی بعدی اعمال می‌شود.").setPositiveButton("حذف",(x,y)->{if(f.delete()){setStatus("فایل حذف شد","برای اعمال حذف روی Documents همگام‌سازی را بزن.",false);showFolder(root,dir);}else setStatus("حذف انجام نشد","فایل قابل حذف نبود.",true);}).setNegativeButton("انصراف",null).show();}).setNegativeButton("انصراف",null).show();}
    private boolean same(File a,File b){try{return a.getCanonicalPath().equals(b.getCanonicalPath());}catch(Exception e){return a.equals(b);}}
    private void openFile(File root,File f){try{Uri u=SecureShareFileProvider.uriFor(this,root,f);String ext=MimeTypeMap.getFileExtensionFromUrl(f.getName());String mime=ext==null?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.US));if(mime==null)mime="application/octet-stream";Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(u,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(this,"خطا در بازکردن فایل: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String human(long n){if(n<1024)return n+" B";double v=n/1024.0;String[] u={"KB","MB","GB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return new DecimalFormat("0.#").format(v)+" "+u[i];}
}
