package com.secureshare.app;

import android.content.Context;
import android.os.Environment;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public final class SyncEngine {
    private static final String MANIFEST_PATH="__secureshare_manifest_v10__";

    public static final class FileState {
        String hash=""; long modified=0,size=0;
        FileState(){}
        FileState(String h,long m,long s){hash=h;modified=m;size=s;}
    }
    public static final class RemoteFile {
        WorldClientDocs.RemoteDocument doc; FileState meta; String path; String sender; String op; String fileId; byte[] data;
    }
    private static final class DeleteRecord {
        String by=""; long at=0; String hash="";
        DeleteRecord(){}
        DeleteRecord(String b,long a,String h){by=b;at=a;hash=h==null?"":h;}
    }
    private static final class DeleteManifest {
        int version=1; Map<String,DeleteRecord> deletes=new HashMap<>();
    }
    private static final class DecodedDoc {
        WorldClientDocs.RemoteDocument doc; Protocol.Header header; byte[] data;
    }
    public static final class Result {
        public int uploaded,downloaded,deletedLocal,deletedRemote,conflicts,cleanupFailed,remoteCandidates,remoteValid,dedupSkipped;
        public String summary(){
            String s="آپلود "+uploaded+" | دانلود "+downloaded+" | حذف محلی "+deletedLocal+" | حذف Documents "+deletedRemote+" | سرور "+remoteValid+"/"+remoteCandidates;
            if(dedupSkipped>0)s+=" | تکراری رد شد "+dedupSkipped;
            if(conflicts>0)s+=" | تداخل "+conflicts;
            if(cleanupFailed>0)s+=" | پاکسازی ناموفق "+cleanupFailed;
            return s;
        }
    }
    private static final class EnsureResult {boolean uploaded;int keepId;EnsureResult(boolean u,int k){uploaded=u;keepId=k;}}
    private static final class RemoteScan {
        Map<String,RemoteFile> latest=new HashMap<>();
        Map<String,List<RemoteFile>> all=new HashMap<>();
        Map<String,List<RemoteFile>> legacyDeletes=new HashMap<>();
        DeleteManifest manifest=new DeleteManifest();
        int candidates,valid;
    }

    private final Context ctx;
    private final AppConfig cfg;
    private final File root;
    private final File stateFile;
    private final JSONObject state;
    private Result result=new Result();

    public SyncEngine(Context ctx,AppConfig cfg)throws Exception{
        this.ctx=ctx.getApplicationContext();this.cfg=cfg;
        root=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SecureShare");
        if(!root.exists()&&!root.mkdirs())throw new IOException("ساخت پوشه Download/SecureShare ممکن نشد");
        File meta=new File(ctx.getFilesDir(),"secureshare_v8");if(!meta.exists())meta.mkdirs();
        stateFile=new File(meta,"state-documents-v8.json");state=loadState();
    }
    public File folder(){return root;}
    public Result getResult(){return result;}

    private JSONObject loadState(){try{if(stateFile.exists())return new JSONObject(new String(Files.readAllBytes(stateFile.toPath()),StandardCharsets.UTF_8));}catch(Exception ignored){}return new JSONObject();}
    private void saveState(){try(FileOutputStream o=new FileOutputStream(stateFile)){o.write(state.toString().getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static FileState stat(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)d.update(b,0,n);}return new FileState(hex(d.digest()),f.lastModified(),f.length());}
    private String rel(File f)throws Exception{String rp=root.getCanonicalPath(),fp=f.getCanonicalPath();if(!fp.startsWith(rp+File.separator))throw new IOException("Unsafe path");return fp.substring(rp.length()+1).replace(File.separatorChar,'/');}
    private File safe(String rel)throws Exception{if(rel.startsWith("/")||rel.contains(":")||rel.contains("../")||rel.equals(".."))throw new IOException("Unsafe path");File f=new File(root,rel.replace('/',File.separatorChar));String rp=root.getCanonicalPath(),fp=f.getCanonicalPath();if(!fp.startsWith(rp+File.separator))throw new IOException("Unsafe path");return f;}
    private void walk(File d,List<File> out){File[] a=d.listFiles();if(a==null)return;for(File f:a){if(f.isDirectory())walk(f,out);else if(!f.getName().endsWith(".secureshare.tmp"))out.add(f);}}
    private Map<String,FileState> local()throws Exception{Map<String,FileState> m=new HashMap<>();List<File> fs=new ArrayList<>();walk(root,fs);for(File f:fs)m.put(rel(f),stat(f));return m;}
    private FileState old(String p){JSONObject o=state.optJSONObject(p);if(o==null)return null;return new FileState(o.optString("hash",""),o.optLong("modified",0),o.optLong("size",0));}
    private void putState(JSONObject target,String p,FileState s)throws Exception{JSONObject o=new JSONObject();o.put("hash",s.hash);o.put("modified",s.modified);o.put("size",s.size);target.put(p,o);}

    public synchronized void sync()throws Exception{
        result=new Result();
        try(WorldClientDocs wc=new WorldClientDocs(cfg)){
            RemoteScan scan=remote(wc);result.remoteCandidates=scan.candidates;result.remoteValid=scan.valid;
            DeleteManifest manifest=scan.manifest;

            // v10 migration: old per-file v9 tombstones are consolidated into the one encrypted manifest.
            boolean manifestChanged=false;
            for(Map.Entry<String,List<RemoteFile>> en:scan.legacyDeletes.entrySet()){
                String p=en.getKey();List<RemoteFile> dels=en.getValue();if(dels==null||dels.isEmpty())continue;
                RemoteFile latest=dels.get(0);for(RemoteFile x:dels)if(x.doc.id>latest.doc.id)latest=x;
                RemoteFile file=scan.latest.get(p);if(file!=null&&file.doc.id>latest.doc.id)continue;
                if(!manifest.deletes.containsKey(p)){manifest.deletes.put(p,new DeleteRecord(latest.sender,latest.meta.modified,latest.meta.hash));manifestChanged=true;}
            }
            if(manifestChanged)persistManifest(wc,manifest);
            for(List<RemoteFile> dels:scan.legacyDeletes.values())cleanupAll(wc,dels);

            Map<String,FileState> local=local();
            Set<String> paths=new TreeSet<>();paths.addAll(scan.latest.keySet());paths.addAll(local.keySet());paths.addAll(manifest.deletes.keySet());Iterator<String> it=state.keys();while(it.hasNext())paths.add(it.next());
            JSONObject next=new JSONObject();

            for(String p:paths){
                RemoteFile r=scan.latest.get(p);FileState l=local.get(p),o=old(p);boolean had=o!=null;
                DeleteRecord del=manifest.deletes.get(p);

                if(del!=null){
                    if(l!=null){
                        boolean sameDeletedVersion=(!del.hash.isEmpty()&&l.hash.equals(del.hash))||(had&&l.hash.equals(o.hash));
                        if(del.by.equals(cfg.deviceId)||!sameDeletedVersion){
                            EnsureResult er=ensureFileOnServer(wc,p,l);if(er.uploaded)result.uploaded++;else result.dedupSkipped++;
                            cleanupAfterEnsure(wc,scan.all.get(p),er);manifest.deletes.remove(p);persistManifest(wc,manifest);putState(next,p,l);continue;
                        }
                        File f=safe(p);if(!f.exists()||f.delete())result.deletedLocal++;
                        cleanupAll(wc,scan.all.get(p));manifest.deletes.remove(p);persistManifest(wc,manifest);continue;
                    }
                    cleanupAll(wc,scan.all.get(p));
                    if(!del.by.equals(cfg.deviceId)){manifest.deletes.remove(p);persistManifest(wc,manifest);}
                    continue;
                }

                if(r!=null&&l!=null){
                    if(r.meta.hash.equals(l.hash)){putState(next,p,l);cleanupOld(wc,scan.all.get(p),r.doc.id);continue;}
                    if(had&&l.hash.equals(o.hash)&&!r.meta.hash.equals(o.hash)){writeRemote(p,r);putState(next,p,r.meta);result.downloaded++;cleanupOld(wc,scan.all.get(p),r.doc.id);continue;}
                    if(had&&r.meta.hash.equals(o.hash)&&!l.hash.equals(o.hash)){
                        EnsureResult er=ensureFileOnServer(wc,p,l);if(er.uploaded)result.uploaded++;else result.dedupSkipped++;cleanupAfterEnsure(wc,scan.all.get(p),er);putState(next,p,l);continue;
                    }
                    writeConflict(p,r);result.conflicts++;
                    EnsureResult er=ensureFileOnServer(wc,p,l);if(er.uploaded)result.uploaded++;else result.dedupSkipped++;cleanupAfterEnsure(wc,scan.all.get(p),er);putState(next,p,l);
                }else if(r!=null){
                    if(had&&o.hash.equals(r.meta.hash)){
                        manifest.deletes.put(p,new DeleteRecord(cfg.deviceId,System.currentTimeMillis(),o.hash));persistManifest(wc,manifest);cleanupAll(wc,scan.all.get(p));
                    }else{
                        writeRemote(p,r);putState(next,p,r.meta);result.downloaded++;cleanupOld(wc,scan.all.get(p),r.doc.id);
                    }
                }else if(l!=null){
                    if(had&&l.hash.equals(o.hash)){putState(next,p,l);continue;}
                    EnsureResult er=ensureFileOnServer(wc,p,l);if(er.uploaded)result.uploaded++;else result.dedupSkipped++;putState(next,p,l);
                }
            }

            List<String> oldKeys=new ArrayList<>();Iterator<String> oi=state.keys();while(oi.hasNext())oldKeys.add(oi.next());for(String k:oldKeys)state.remove(k);
            Iterator<String> ni=next.keys();while(ni.hasNext()){String k=ni.next();state.put(k,next.get(k));}
            saveState();
        }
    }

    private void cleanupOld(WorldClientDocs wc,List<RemoteFile> all,int keep){if(all==null)return;for(RemoteFile x:all){if(x.doc.id==keep)continue;if(wc.delete(x.doc))result.deletedRemote++;else result.cleanupFailed++;}}
    private void cleanupAll(WorldClientDocs wc,List<RemoteFile> all){if(all==null)return;for(RemoteFile x:all){if(wc.delete(x.doc))result.deletedRemote++;else result.cleanupFailed++;}}
    private void cleanupAfterEnsure(WorldClientDocs wc,List<RemoteFile> all,EnsureResult er){if(er.uploaded)cleanupAll(wc,all);else cleanupOld(wc,all,er.keepId);}

    private DecodedDoc decodePacketDoc(WorldClientDocs wc,WorldClientDocs.RemoteDocument d){
        try{
            byte[] enc=wc.download(d.id),plain;
            try{plain=CryptoUtil.decrypt(AppConfig.sharedPassphrase(cfg.password),enc);}catch(Exception primary){plain=CryptoUtil.decrypt(AppConfig.legacyPassphrase(cfg.password),enc);}
            Protocol.Parsed p=Protocol.unpack(plain);DecodedDoc out=new DecodedDoc();out.doc=d;out.header=p.header;out.data=p.data;return out;
        }catch(Exception x){return null;}
    }
    private static DeleteManifest parseManifest(byte[] data){
        DeleteManifest m=new DeleteManifest();
        try{
            JSONObject j=new JSONObject(new String(data,StandardCharsets.UTF_8));m.version=j.optInt("v",1);JSONObject ds=j.optJSONObject("deletes");if(ds==null)return m;
            Iterator<String> it=ds.keys();while(it.hasNext()){String p=it.next();JSONObject o=ds.optJSONObject(p);if(o!=null)m.deletes.put(p,new DeleteRecord(o.optString("by",""),o.optLong("at",0),o.optString("hash","")));}
        }catch(Exception ignored){}
        return m;
    }
    private static byte[] manifestBytes(DeleteManifest m)throws Exception{
        JSONObject j=new JSONObject();j.put("v",1);JSONObject ds=new JSONObject();
        for(Map.Entry<String,DeleteRecord> en:m.deletes.entrySet()){DeleteRecord r=en.getValue();JSONObject o=new JSONObject();o.put("by",r.by);o.put("at",r.at);if(!r.hash.isEmpty())o.put("hash",r.hash);ds.put(en.getKey(),o);}j.put("deletes",ds);return j.toString().getBytes(StandardCharsets.UTF_8);
    }
    private RemoteScan remote(WorldClientDocs wc)throws Exception{
        RemoteScan scan=new RemoteScan();List<WorldClientDocs.RemoteDocument> docs=wc.list();scan.candidates=docs.size();int latestManifestId=0;
        for(WorldClientDocs.RemoteDocument d:docs){
            DecodedDoc dd=decodePacketDoc(wc,d);if(dd==null)continue;Protocol.Header h=dd.header;
            if("file".equals(h.op)&&!h.path.isEmpty()){
                scan.valid++;RemoteFile rf=new RemoteFile();rf.doc=d;rf.path=h.path;rf.sender=h.sender;rf.op=h.op;rf.fileId=h.fileId;rf.data=dd.data;rf.meta=new FileState(h.hash,h.modified,h.size);
                List<RemoteFile> list=scan.all.get(h.path);if(list==null){list=new ArrayList<>();scan.all.put(h.path,list);}list.add(rf);RemoteFile prev=scan.latest.get(h.path);if(prev==null||d.id>prev.doc.id)scan.latest.put(h.path,rf);
            }else if("delete".equals(h.op)&&!h.path.isEmpty()){
                scan.valid++;RemoteFile rf=new RemoteFile();rf.doc=d;rf.path=h.path;rf.sender=h.sender;rf.op=h.op;rf.fileId=h.fileId;rf.data=dd.data;rf.meta=new FileState(h.hash,h.modified,h.size);
                List<RemoteFile> list=scan.legacyDeletes.get(h.path);if(list==null){list=new ArrayList<>();scan.legacyDeletes.put(h.path,list);}list.add(rf);
            }else if("manifest".equals(h.op)){
                scan.valid++;if(d.id>latestManifestId){latestManifestId=d.id;scan.manifest=parseManifest(dd.data);}
            }
        }
        return scan;
    }
    private List<RemoteFile> findRemoteVersion(WorldClientDocs wc,String path,String hash)throws Exception{
        List<RemoteFile> out=new ArrayList<>();for(WorldClientDocs.RemoteDocument d:wc.list()){DecodedDoc dd=decodePacketDoc(wc,d);if(dd==null)continue;Protocol.Header h=dd.header;if(!"file".equals(h.op)||!path.equals(h.path)||!hash.equals(h.hash))continue;RemoteFile rf=new RemoteFile();rf.doc=d;rf.path=h.path;rf.sender=h.sender;rf.op=h.op;rf.fileId=h.fileId;rf.data=dd.data;rf.meta=new FileState(h.hash,h.modified,h.size);out.add(rf);}return out;
    }
    private List<WorldClientDocs.RemoteDocument> findManifestDocs(WorldClientDocs wc)throws Exception{
        List<WorldClientDocs.RemoteDocument> out=new ArrayList<>();for(WorldClientDocs.RemoteDocument d:wc.list()){DecodedDoc dd=decodePacketDoc(wc,d);if(dd!=null&&"manifest".equals(dd.header.op))out.add(d);}return out;
    }
    private void persistManifest(WorldClientDocs wc,DeleteManifest m)throws Exception{
        List<WorldClientDocs.RemoteDocument> old=findManifestDocs(wc);
        if(m.deletes.isEmpty()){
            for(WorldClientDocs.RemoteDocument d:old){if(wc.delete(d))result.deletedRemote++;else result.cleanupFailed++;}return;
        }
        Protocol.Header h=new Protocol.Header();h.op="manifest";h.path=MANIFEST_PATH;h.modified=System.currentTimeMillis();h.sender=cfg.deviceId;h.fileId=WorldClientDocs.manifestFileId();
        byte[] pkt=Protocol.pack(h,manifestBytes(m));byte[] enc=CryptoUtil.encrypt(AppConfig.sharedPassphrase(cfg.password),pkt);wc.upload(WorldClientDocs.remoteNameForManifest(),enc);
        List<WorldClientDocs.RemoteDocument> all=findManifestDocs(wc);int keep=0;for(WorldClientDocs.RemoteDocument d:all)if(d.id>keep)keep=d.id;
        for(WorldClientDocs.RemoteDocument d:all){if(d.id==keep)continue;if(wc.delete(d))result.deletedRemote++;else result.cleanupFailed++;}
    }

    private EnsureResult ensureFileOnServer(WorldClientDocs wc,String path,FileState s)throws Exception{
        List<RemoteFile> existing=findRemoteVersion(wc,path,s.hash);
        if(!existing.isEmpty()){RemoteFile keep=existing.get(existing.size()-1);cleanupOld(wc,existing,keep.doc.id);return new EnsureResult(false,keep.doc.id);}
        File f=safe(path);byte[] data=Files.readAllBytes(f.toPath());Protocol.Header h=new Protocol.Header();h.op="file";h.path=path;h.hash=s.hash;h.modified=s.modified;h.size=s.size;h.sender=cfg.deviceId;h.fileId=WorldClientDocs.versionFileId(path,s.hash);
        byte[] pkt=Protocol.pack(h,data);byte[] enc=CryptoUtil.encrypt(AppConfig.sharedPassphrase(cfg.password),pkt);wc.upload(WorldClientDocs.remoteNameForVersion(path,s.hash),enc);return new EnsureResult(true,0);
    }

    private void writeRemote(String path,RemoteFile r)throws Exception{
        File dest=safe(path);if(dest.getParentFile()!=null)dest.getParentFile().mkdirs();File tmp=new File(dest.getPath()+".secureshare.tmp");try(FileOutputStream o=new FileOutputStream(tmp)){o.write(r.data);}
        FileState st=stat(tmp);if(!st.hash.equals(r.meta.hash)){tmp.delete();throw new IOException("Remote file hash mismatch");}if(dest.exists())dest.delete();if(!tmp.renameTo(dest))throw new IOException("Cannot replace file");if(r.meta.modified>0)dest.setLastModified(r.meta.modified);
    }
    private void writeConflict(String path,RemoteFile r)throws Exception{
        File dest=safe(path);String n=dest.getName();int dot=n.lastIndexOf('.');String b=dot>0?n.substring(0,dot):n,e=dot>0?n.substring(dot):"";String t=new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());File c=new File(dest.getParentFile(),b+" (remote conflict "+t+")"+e);if(c.getParentFile()!=null)c.getParentFile().mkdirs();try(FileOutputStream o=new FileOutputStream(c)){o.write(r.data);}
    }
}
