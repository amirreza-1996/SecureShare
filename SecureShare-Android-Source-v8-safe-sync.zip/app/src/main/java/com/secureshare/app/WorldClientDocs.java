package com.secureshare.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class WorldClientDocs implements Closeable {
    public static final class RemoteDocument {
        public int id; public String name; public String deleteUrl;
        public RemoteDocument(int id,String name,String deleteUrl){this.id=id;this.name=name;this.deleteUrl=deleteUrl;}
    }

    private final AppConfig cfg;
    private final CookieManager cookies=new CookieManager(null,CookiePolicy.ACCEPT_ALL);
    private final String base;
    private String session="";

    private static final Pattern SESSION_RE=Pattern.compile("(?i)(?:[?&]|&amp;)Session=([A-Za-z0-9_-]+)");
    private static final Pattern ROW_RE=Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern DOWNLOAD_RE=Pattern.compile("(?i)(?:[?&]|&amp;|%26)Download(?:=|%3D)(\\d+)");
    private static final Pattern SECURE_NAME_RE=Pattern.compile("SS_[0-9a-fA-F]{40}\\.bin");
    private static final Pattern LINK_RE=Pattern.compile("(?is)(?:href|src|action)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern URL_IN_JS_RE=Pattern.compile("(?i)(WorldClient\\.dll\\?[^\\\"'\\s)]+)");
    private static final Pattern JSON_ID_RE=Pattern.compile("(?i)\\\"[^\\\"]*(?:id|download)[^\\\"]*\\\"\\s*:\\s*\\\"?(\\d{1,10})\\\"?");
    private static final Pattern ATTR_ID_RE=Pattern.compile("(?i)(?:data-(?:document-)?id|documentid|docid)\\s*=\\s*[\\\"']?(\\d{1,10})");
    private static final Pattern QUERY_ID_RE=Pattern.compile("(?i)(?:[?&]|&amp;)(?:DocumentID|DocID|FileID|ID)=(\\d{1,10})");

    public WorldClientDocs(AppConfig cfg)throws Exception{this.cfg=cfg;this.base=normalizeBase(cfg.server);CookieHandler.setDefault(cookies);login();}
    private static String normalizeBase(String s){s=s.trim();while(s.endsWith("/"))s=s.substring(0,s.length()-1);String l=s.toLowerCase(Locale.US);if(!l.startsWith("http://")&&!l.startsWith("https://"))s="https://"+s;return s;}
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[65536];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toByteArray();}
    private static String bodyText(HttpURLConnection c)throws Exception{InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(in==null)return "";return new String(readAll(in),StandardCharsets.UTF_8);}
    private HttpURLConnection open(String u,String method)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setInstanceFollowRedirects(true);c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setRequestMethod(method);c.setRequestProperty("User-Agent","SecureShare/2.1");return c;}

    private void login()throws Exception{
        String u=base+"/WorldClient.dll?View=Main&User="+enc(cfg.username)+"&Password="+enc(cfg.password);
        HttpURLConnection c=open(u,"GET");String body=bodyText(c);int code=c.getResponseCode();String finalUrl=c.getURL().toString();c.disconnect();
        if(code<200||code>=400)throw new IOException("ورود Webmail: HTTP "+code);
        Matcher m=SESSION_RE.matcher(finalUrl);if(m.find())session=m.group(1);if(session.isEmpty()){m=SESSION_RE.matcher(body);if(m.find())session=m.group(1);}if(session.isEmpty())throw new IOException("ورود Webmail انجام نشد؛ Session دریافت نشد");
    }
    @Override public void close(){try{if(!session.isEmpty()){HttpURLConnection c=open(base+"/WorldClient.dll?Session="+enc(session)+"&View=LogOut","GET");c.getResponseCode();c.disconnect();}}catch(Exception ignored){}}

    private String listUrl(String extra)throws Exception{return base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+(extra==null||extra.isEmpty()?"":"&"+extra);}
    private String getText(String u)throws Exception{HttpURLConnection c=open(u,"GET");String b=bodyText(c);int code=c.getResponseCode();c.disconnect();if(code<200||code>=400)throw new IOException("Documents list: HTTP "+code);return b;}
    private List<String> listBodies()throws Exception{
        String[] extras={"","GETJSON=Yes","GETJSON=Yes&ContentType=json","ReturnJavaScript=Yes&GETJSON=Yes&ContentType=javascript","Search=SS_","SearchText=SS_"};
        LinkedHashSet<String> bodies=new LinkedHashSet<>();Exception first=null;
        for(String x:extras){try{bodies.add(getText(listUrl(x)));}catch(Exception e){if(first==null)first=e;}}
        if(bodies.isEmpty()&&first!=null)throw first;return new ArrayList<>(bodies);
    }
    private static String htmlUnescape(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">");}
    private static void addIds(Pattern p,String s,Set<Integer> ids){Matcher m=p.matcher(s);while(m.find()){try{int id=Integer.parseInt(m.group(1));if(id>0)ids.add(id);}catch(Exception ignored){}}}
    private static Set<Integer> extractIds(String body){LinkedHashSet<Integer> ids=new LinkedHashSet<>();ArrayList<String> vars=new ArrayList<>();vars.add(body);vars.add(htmlUnescape(body));try{vars.add(URLDecoder.decode(body,"UTF-8"));}catch(Exception ignored){}for(String s:vars){addIds(DOWNLOAD_RE,s,ids);addIds(JSON_ID_RE,s,ids);addIds(ATTR_ID_RE,s,ids);addIds(QUERY_ID_RE,s,ids);}ids.remove(AppConfig.DOCUMENTS_FOLDER_ID);return ids;}

    public List<RemoteDocument> list()throws Exception{
        LinkedHashMap<Integer,RemoteDocument> docs=new LinkedHashMap<>();
        for(String html:listBodies()){
            Matcher rm=ROW_RE.matcher(html);while(rm.find()){
                String row=rm.group(1);Set<Integer> ids=extractIds(row);if(ids.isEmpty())continue;String name="";Matcher nm=SECURE_NAME_RE.matcher(row);if(nm.find())name=nm.group();String del="";Matcher lm=LINK_RE.matcher(row);while(lm.find()){String h=htmlUnescape(lm.group(1));String l=h.toLowerCase(Locale.US);if(l.contains("delete")||l.contains("remove")){del=h;break;}if(l.startsWith("javascript:")){Matcher jm=URL_IN_JS_RE.matcher(h);if(jm.find()){String cand=htmlUnescape(jm.group(1));String lc=cand.toLowerCase(Locale.US);if(lc.contains("delete")||lc.contains("remove")){del=cand;break;}}}}
                for(int id:ids){RemoteDocument d=docs.get(id);if(d==null)d=new RemoteDocument(id,"","");if(d.name.isEmpty())d.name=name;if(d.deleteUrl.isEmpty())d.deleteUrl=del;docs.put(id,d);}
            }
            for(int id:extractIds(html))if(!docs.containsKey(id))docs.put(id,new RemoteDocument(id,"",""));
        }
        ArrayList<Integer> ids=new ArrayList<>(docs.keySet());Collections.sort(ids);if(ids.size()>500)ids=new ArrayList<>(ids.subList(ids.size()-500,ids.size()));ArrayList<RemoteDocument> out=new ArrayList<>();for(int id:ids)out.add(docs.get(id));return out;
    }

    public byte[] download(int id)throws Exception{String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Download="+id;HttpURLConnection c=open(u,"GET");int code=c.getResponseCode();if(code!=200){c.disconnect();throw new IOException("دانلود Document "+id+": HTTP "+code);}byte[] b=readAll(c.getInputStream());c.disconnect();return b;}

    public void upload(String name,byte[] data)throws Exception{
        String boundary="----SecureShare"+System.nanoTime();String u=base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&ReturnJavaScript=Yes&Upload=Yes&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&GETJSON=Yes&ContentType=javascript";HttpURLConnection c=open(u,"POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);OutputStream out=c.getOutputStream();String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\"Attachment:0\"; filename=\""+name+"\"\r\nContent-Type: application/octet-stream\r\n\r\n";out.write(head.getBytes(StandardCharsets.UTF_8));out.write(data);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();out.close();int code=c.getResponseCode();try{bodyText(c);}catch(Exception ignored){}c.disconnect();if(code<200||code>=300)throw new IOException("آپلود Documents: HTTP "+code);
    }

    private URL resolve(String raw)throws Exception{raw=htmlUnescape(raw.trim());if(raw.toLowerCase(Locale.US).startsWith("javascript:")){Matcher m=URL_IN_JS_RE.matcher(raw);if(!m.find())return null;raw=m.group(1);}return new URL(new URL(base+"/"),raw);}
    private boolean payloadExists(int id){try{byte[] b=download(id);return b.length>=4&&b[0]=='S'&&b[1]=='S'&&b[2]=='E'&&b[3]=='1';}catch(Exception e){return false;}}
    private void tryGetDelete(String raw){try{URL u=resolve(raw);if(u==null)return;String s=u.toString();if(!s.toLowerCase(Locale.US).contains("session="))s+=(s.contains("?")?"&":"?")+"Session="+enc(session);HttpURLConnection c=open(s,"GET");try{bodyText(c);}catch(Exception ignored){}c.disconnect();}catch(Exception ignored){}}
    private void tryPostDelete(Map<String,String> fields){try{LinkedHashMap<String,String> f=new LinkedHashMap<>(fields);f.put("Session",session);f.put("View","DocumentList");f.put("FolderID",Integer.toString(AppConfig.DOCUMENTS_FOLDER_ID));StringBuilder b=new StringBuilder();for(Map.Entry<String,String> e:f.entrySet()){if(b.length()>0)b.append('&');b.append(enc(e.getKey())).append('=').append(enc(e.getValue()));}HttpURLConnection c=open(base+"/WorldClient.dll","POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream o=c.getOutputStream()){o.write(b.toString().getBytes(StandardCharsets.UTF_8));}try{bodyText(c);}catch(Exception ignored){}c.disconnect();}catch(Exception ignored){}}

    public boolean delete(RemoteDocument d){
        if(!payloadExists(d.id))return true;if(d.deleteUrl!=null&&!d.deleteUrl.isEmpty()){tryGetDelete(d.deleteUrl);if(!payloadExists(d.id))return true;}
        try{String[] gets={base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Delete="+d.id,base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&DeleteDocument="+d.id,base+"/WorldClient.dll?Session="+enc(session)+"&View=DocumentList&FolderID="+AppConfig.DOCUMENTS_FOLDER_ID+"&Remove="+d.id};for(String g:gets){tryGetDelete(g);if(!payloadExists(d.id))return true;}}catch(Exception ignored){}
        String id=Integer.toString(d.id);String[][] forms={{"Delete",id},{"DeleteDocument",id},{"Remove",id},{"Delete","Yes","DocumentID",id},{"Delete","Yes","ID",id},{"Action","Delete","DocumentID",id},{"Action","Delete","ID",id},{"DeleteSelected","Yes","Selected",id},{"DeleteSelected","Yes","DocumentID",id}};
        for(String[] arr:forms){LinkedHashMap<String,String> m=new LinkedHashMap<>();for(int i=0;i+1<arr.length;i+=2)m.put(arr[i],arr[i+1]);tryPostDelete(m);if(!payloadExists(d.id))return true;}return false;
    }

    public static String remoteNameForPath(String path,String password)throws Exception{Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(AppConfig.SHARED_SECRET.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));byte[] d=m.doFinal(path.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder("SS_");for(int i=0;i<20;i++)s.append(String.format(Locale.US,"%02x",d[i]));return s+".bin";}
}
